'use client'

import Link from 'next/link'
import { useMemo, useState } from 'react'
import { Disc3, Download, ExternalLink, Search } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { PageContainer, PageHeader } from '@/components/app/page-header'
import { cn } from '@/lib/utils'
import { sheetIssues } from '@/lib/splits'
import { useHydrated, useSheets } from '@/lib/sheets-store'
import { ISRC_PURCHASE_URL } from '@/lib/partner-services'

function csvCell(value: string | number) {
  const s = String(value)
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
}

export function Catalog() {
  const hydrated = useHydrated()
  const sheets = useSheets()
  const [query, setQuery] = useState('')

  const rows = useMemo(
    () =>
      [...sheets]
        .sort((a, b) => a.song.title.localeCompare(b.song.title))
        .map((s) => ({ sheet: s, issues: sheetIssues(s.song, s.contributors) }))
        .filter(({ sheet }) => {
          const q = query.trim().toLowerCase()
          return !q || [sheet.song.title, sheet.song.artist, sheet.song.isrc].some((v) => v.toLowerCase().includes(q))
        }),
    [sheets, query],
  )

  function exportCsv() {
    const header = ['Title', 'Artist', 'ISRC', 'Date', 'Master owner', 'Master owner type', 'Contributor', 'Role', 'IPI', 'PRO', 'Publisher', 'Publisher IPI', 'Publisher PRO', 'Master %', 'Publishing %']
    const lines = sheets.flatMap((s) =>
      s.contributors.map((c) =>
        [s.song.title, s.song.artist, s.song.isrc, s.song.date, s.song.masterOwner, s.song.masterOwnerType, c.name, c.role, c.ipi, c.pro, c.publisherName, c.publisherIpi, c.publisherPro, c.master, c.publishing]
          .map(csvCell)
          .join(','),
      ),
    )
    const blob = new Blob([[header.join(','), ...lines].join('\n')], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'splits-music-catalog.csv'
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <PageContainer>
      <PageHeader
        eyebrow="Catalog"
        title="Your songs"
        description="Every song you have a split sheet for, with ISRC and registration status at a glance."
        actions={
          <Button variant="outline" className="h-10 rounded-full px-4" onClick={exportCsv} disabled={!hydrated || sheets.length === 0}>
            <Download data-icon="inline-start" />
            Export CSV
          </Button>
        }
      />

      <label className="relative mt-8 block sm:w-80">
        <span className="sr-only">Search catalog</span>
        <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search title, artist or ISRC"
          className="h-10 w-full rounded-full border border-input bg-card pl-10 pr-4 text-sm outline-none placeholder:text-muted-foreground focus-visible:ring-3 focus-visible:ring-ring/40"
        />
      </label>

      <div className="mt-5 overflow-hidden rounded-3xl border border-border bg-card">
        {!hydrated ? (
          <div className="h-48 animate-pulse bg-muted" />
        ) : sheets.length === 0 ? (
          <div className="flex flex-col items-center gap-3 px-6 py-16 text-center">
            <Disc3 className="size-7 text-muted-foreground" aria-hidden="true" />
            <p className="text-sm text-muted-foreground">Your catalog fills up as you create split sheets.</p>
            <Button nativeButton={false} render={<Link href="/dashboard/sheets/new" />} size="sm" className="rounded-full">
              Create a sheet
            </Button>
          </div>
        ) : rows.length === 0 ? (
          <p className="p-10 text-center text-sm text-muted-foreground">No songs match your search.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-sm">
              <thead>
                <tr className="border-b border-border text-left text-xs text-muted-foreground">
                  <th scope="col" className="px-5 py-3 font-medium">Song</th>
                  <th scope="col" className="px-5 py-3 font-medium">ISRC</th>
                  <th scope="col" className="px-5 py-3 font-medium">Contributors</th>
                  <th scope="col" className="px-5 py-3 font-medium">Registration</th>
                  <th scope="col" className="px-5 py-3 font-medium">
                    <span className="sr-only">Open</span>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {rows.map(({ sheet, issues }) => (
                  <tr key={sheet.id} className="transition-colors hover:bg-secondary/50">
                    <td className="px-5 py-3.5">
                      <p className="font-medium">{sheet.song.title.trim() || 'Untitled sheet'}</p>
                      <p className="text-xs text-muted-foreground">{sheet.song.artist || 'No artist'}</p>
                    </td>
                    <td className="px-5 py-3.5">
                      {sheet.song.isrc.trim() ? (
                        <span className="font-mono text-xs">{sheet.song.isrc}</span>
                      ) : (
                        <a
                          href={ISRC_PURCHASE_URL}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-xs font-medium text-primary hover:underline"
                        >
                          Get an ISRC
                          <ExternalLink className="size-3" aria-hidden="true" />
                        </a>
                      )}
                    </td>
                    <td className="px-5 py-3.5 tabular-nums">{sheet.contributors.length}</td>
                    <td className="px-5 py-3.5">
                      <span
                        className={cn(
                          'rounded-full px-2.5 py-0.5 text-xs font-medium',
                          issues.length === 0 ? 'bg-accent text-accent-foreground' : 'bg-muted text-muted-foreground',
                        )}
                      >
                        {issues.length === 0 ? 'Ready to register' : `${issues.length} to fix`}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <Link href={`/dashboard/sheets/${sheet.id}`} className="text-sm font-medium text-primary hover:underline">
                        Open
                        <span className="sr-only"> {sheet.song.title || 'sheet'}</span>
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </PageContainer>
  )
}
