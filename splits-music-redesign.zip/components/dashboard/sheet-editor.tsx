'use client'

import Link from 'next/link'
import { FileQuestion, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { SplitBuilder } from '@/components/builder/split-builder'
import { isFullySigned, useHydrated, useSheets } from '@/lib/sheets-store'
import { SignedSheetView } from './signed-sheet-view'

export function SheetEditor({ id }: { id: string }) {
  const hydrated = useHydrated()
  const sheets = useSheets()

  if (!hydrated) {
    return (
      <div className="flex min-h-[60dvh] items-center justify-center gap-2 text-sm text-muted-foreground" role="status">
        <Loader2 className="size-4 animate-spin" aria-hidden="true" />
        Loading sheet…
      </div>
    )
  }

  const sheet = sheets.find((s) => s.id === id)

  if (!sheet) {
    return (
      <div className="mx-auto flex min-h-[60dvh] max-w-md flex-col items-center justify-center gap-4 px-4 text-center">
        <span className="flex size-12 items-center justify-center rounded-2xl bg-muted">
          <FileQuestion className="size-6 text-muted-foreground" aria-hidden="true" />
        </span>
        <div>
          <h1 className="text-xl font-semibold">Sheet not found</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            This sheet was deleted, or it belongs to someone else. Sheets are only visible to the person who created them.
          </p>
        </div>
        <Button nativeButton={false} render={<Link href="/dashboard/sheets" />} className="rounded-full">
          Back to my sheets
        </Button>
      </div>
    )
  }

  if (sheet.status === 'signed' && isFullySigned(sheet)) return <SignedSheetView sheet={sheet} />

  return <SplitBuilder key={sheet.id} initial={sheet} />
}
