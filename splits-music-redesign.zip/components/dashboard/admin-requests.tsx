'use client'

import { useMemo } from 'react'
import { Check, Inbox, RotateCcw, ShieldCheck, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { PageContainer, PageHeader } from '@/components/app/page-header'
import { cn } from '@/lib/utils'
import { resolveRemoval, restoreSheet, useAllSheets, useHydrated, type SavedSheet } from '@/lib/sheets-store'

const formatDate = (iso: string) => new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })

export function AdminRequests() {
  const hydrated = useHydrated()
  const sheets = useAllSheets()

  const pending = useMemo(
    () => sheets.filter((s) => s.removal?.status === 'pending').sort((a, b) => a.removal!.requestedAt.localeCompare(b.removal!.requestedAt)),
    [sheets],
  )
  const history = useMemo(
    () =>
      sheets
        .filter((s) => s.removal && s.removal.status !== 'pending')
        .sort((a, b) => (b.removal!.resolvedAt ?? '').localeCompare(a.removal!.resolvedAt ?? '')),
    [sheets],
  )

  return (
    <PageContainer>
      <PageHeader
        eyebrow={
          <>
            <ShieldCheck className="size-3.5" aria-hidden="true" />
            Admin
          </>
        }
        title="Removal requests"
        description="Fully signed sheets stay on record until an admin approves their removal. Approved sheets are hidden from the owner's dashboard but kept for audit."
      />

      <p className="mt-6 rounded-2xl border border-dashed border-border bg-card/60 p-4 text-sm text-muted-foreground">
        Preview mode: once real accounts are connected, this page is restricted to platform admins.
      </p>

      <section aria-labelledby="pending-heading" className="mt-8">
        <h2 id="pending-heading" className="flex items-center gap-2 text-sm font-semibold">
          Pending
          <span className="rounded-full bg-muted px-2 py-0.5 font-mono text-xs tabular-nums">{hydrated ? pending.length : '–'}</span>
        </h2>
        {!hydrated ? (
          <div className="mt-3 h-32 animate-pulse rounded-3xl border border-border bg-card" aria-hidden="true" />
        ) : pending.length === 0 ? (
          <div className="mt-3 flex flex-col items-center gap-2 rounded-3xl border border-dashed border-border px-6 py-12 text-center">
            <Inbox className="size-6 text-muted-foreground" aria-hidden="true" />
            <p className="text-sm text-muted-foreground">No requests waiting for review.</p>
          </div>
        ) : (
          <ul className="mt-3 flex flex-col gap-3">
            {pending.map((s) => (
              <RequestCard key={s.id} sheet={s} />
            ))}
          </ul>
        )}
      </section>

      {hydrated && history.length > 0 && (
        <section aria-labelledby="history-heading" className="mt-10">
          <h2 id="history-heading" className="text-sm font-semibold">
            History
          </h2>
          <ul className="mt-3 divide-y divide-border rounded-3xl border border-border bg-card">
            {history.map((s) => {
              const approved = s.removal!.status === 'approved'
              return (
                <li key={s.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{s.song.title || 'Untitled sheet'}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {s.removal!.resolvedAt ? formatDate(s.removal!.resolvedAt) : ''} · {s.removal!.reason}
                    </p>
                  </div>
                  <span
                    className={cn(
                      'rounded-full px-2.5 py-0.5 text-xs font-medium',
                      approved ? 'bg-accent text-accent-foreground' : 'bg-destructive/15 text-destructive',
                    )}
                  >
                    {approved ? 'Removed' : 'Declined'}
                  </span>
                  {approved && (
                    <Button size="sm" variant="ghost" className="rounded-full" onClick={() => restoreSheet(s.id)}>
                      <RotateCcw data-icon="inline-start" />
                      Restore
                    </Button>
                  )}
                </li>
              )
            })}
          </ul>
        </section>
      )}
    </PageContainer>
  )
}

function RequestCard({ sheet }: { sheet: SavedSheet }) {
  const title = sheet.song.title.trim() || 'Untitled sheet'
  return (
    <li className="flex flex-col gap-4 rounded-3xl border border-border bg-card p-5 sm:flex-row sm:items-start">
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <h3 className="font-semibold">{title}</h3>
          <span className="text-sm text-muted-foreground">{sheet.song.artist}</span>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">
          {sheet.contributors.length} signatories · requested {formatDate(sheet.removal!.requestedAt)}
        </p>
        <p className="mt-3 rounded-xl bg-muted p-3 text-sm">&ldquo;{sheet.removal!.reason}&rdquo;</p>
      </div>
      <div className="flex gap-2 sm:flex-col">
        <Button size="sm" className="rounded-full" onClick={() => resolveRemoval(sheet.id, true)} aria-label={`Approve removal of ${title}`}>
          <Check data-icon="inline-start" />
          Approve
        </Button>
        <Button
          size="sm"
          variant="outline"
          className="rounded-full"
          onClick={() => resolveRemoval(sheet.id, false)}
          aria-label={`Decline removal of ${title}`}
        >
          <X data-icon="inline-start" />
          Decline
        </Button>
      </div>
    </li>
  )
}
