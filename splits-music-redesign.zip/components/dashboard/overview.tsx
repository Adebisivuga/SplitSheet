'use client'

import Link from 'next/link'
import { useMemo } from 'react'
import { AlertCircle, ArrowRight, Calculator, CheckCircle2, Circle, Disc3, FileText, Plus, Sparkles, Users } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/app/form-field'
import { PageContainer, PageHeader } from '@/components/app/page-header'
import { cn } from '@/lib/utils'
import { sheetIssues, swatchFor } from '@/lib/splits'
import { STATUS_LABEL, useHydrated, useSheets } from '@/lib/sheets-store'
import { profileChecks, profileCompleteness, useProfile } from '@/lib/profile-store'
import { useCollaborators } from '@/lib/collaborators-store'

const QUICK_ACTIONS = [
  { href: '/dashboard/sheets/new', label: 'New split sheet', desc: 'Agree shares in minutes', icon: Plus },
  { href: '/dashboard/royalties', label: 'Royalty calculator', desc: 'See who gets paid what', icon: Calculator },
  { href: '/dashboard/collaborators', label: 'Collaborators', desc: 'Save IPI & PRO details', icon: Users },
  { href: '/dashboard/services', label: 'ISRC & metadata', desc: 'Trusted partner services', icon: Sparkles },
]

export function Overview() {
  const hydrated = useHydrated()
  const sheets = useSheets()
  const profile = useProfile()
  const collaborators = useCollaborators()

  const recent = useMemo(() => [...sheets].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)).slice(0, 4), [sheets])
  const needsAttention = useMemo(
    () => sheets.map((s) => ({ sheet: s, issues: sheetIssues(s.song, s.contributors) })).filter((x) => x.issues.length > 0),
    [sheets],
  )
  const missingIsrc = sheets.filter((s) => !s.song.isrc.trim()).length
  const completeness = profileCompleteness(profile)
  const firstName = profile.name.trim().split(/\s+/)[0]

  const stats = [
    { label: 'Split sheets', value: sheets.length, icon: FileText, href: '/dashboard/sheets' },
    { label: 'Ready to sign', value: sheets.filter((s) => s.status === 'ready').length, icon: CheckCircle2, href: '/dashboard/sheets' },
    { label: 'Songs missing ISRC', value: missingIsrc, icon: Disc3, href: '/dashboard/catalog' },
    { label: 'Saved collaborators', value: collaborators.length, icon: Users, href: '/dashboard/collaborators' },
  ]

  return (
    <PageContainer>
      <PageHeader
        eyebrow="Workspace"
        title={hydrated && firstName ? `Welcome back, ${firstName}` : 'Welcome to your workspace'}
        description="Everything for your songs in one place — split sheets, catalog, collaborators and royalties."
        actions={
          <Button nativeButton={false} render={<Link href="/dashboard/sheets/new" />} className="h-10 rounded-full px-4">
            <Plus data-icon="inline-start" />
            New split sheet
          </Button>
        }
      />

      <dl className="mt-8 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {stats.map((s) => {
          const Icon = s.icon
          return (
            <Link
              key={s.label}
              href={s.href}
              className="group rounded-2xl border border-border bg-card p-4 transition-colors hover:border-primary/40"
            >
              <div className="flex items-center justify-between">
                <dt className="text-xs font-medium text-muted-foreground">{s.label}</dt>
                <Icon className="size-4 text-muted-foreground transition-colors group-hover:text-primary" aria-hidden="true" />
              </div>
              <dd className="mt-2 font-mono text-3xl font-semibold tabular-nums">{hydrated ? s.value : '–'}</dd>
            </Link>
          )
        })}
      </dl>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_340px]">
        <div className="flex flex-col gap-6">
          <Card>
            <div className="flex items-center justify-between gap-3">
              <h2 className="font-semibold">Recent sheets</h2>
              <Link href="/dashboard/sheets" className="inline-flex items-center gap-1 text-sm text-primary hover:underline">
                View all
                <ArrowRight className="size-3.5" aria-hidden="true" />
              </Link>
            </div>
            {!hydrated ? (
              <div className="mt-4 h-40 animate-pulse rounded-2xl bg-muted" />
            ) : recent.length === 0 ? (
              <div className="mt-4 flex flex-col items-center gap-3 rounded-2xl border border-dashed border-border px-6 py-10 text-center">
                <FileText className="size-6 text-muted-foreground" aria-hidden="true" />
                <p className="text-sm text-muted-foreground">No sheets yet. Start your first one to see it here.</p>
                <Button nativeButton={false} render={<Link href="/dashboard/sheets/new" />} size="sm" className="rounded-full">
                  Create a sheet
                </Button>
              </div>
            ) : (
              <ul className="mt-3 divide-y divide-border">
                {recent.map((s) => (
                  <li key={s.id}>
                    <Link
                      href={`/dashboard/sheets/${s.id}`}
                      className="-mx-2 flex items-center gap-4 rounded-xl px-2 py-3 transition-colors hover:bg-secondary/60"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">{s.song.title.trim() || 'Untitled sheet'}</p>
                        <p className="truncate text-xs text-muted-foreground">
                          {s.song.artist || 'No artist'} · {s.contributors.length} contributors
                        </p>
                      </div>
                      <div className="hidden h-1.5 w-28 gap-0.5 overflow-hidden rounded-full bg-muted sm:flex" aria-hidden="true">
                        {s.contributors.map((c, i) =>
                          c.publishing > 0 ? (
                            <span key={c.id} className={cn('rounded-full', swatchFor(i))} style={{ width: `${c.publishing}%` }} />
                          ) : null,
                        )}
                      </div>
                      <span
                        className={cn(
                          'shrink-0 rounded-full px-2.5 py-0.5 text-xs font-medium',
                          s.status === 'draft' ? 'bg-muted text-muted-foreground' : 'bg-accent text-accent-foreground',
                        )}
                      >
                        {STATUS_LABEL[s.status]}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <section aria-labelledby="quick-actions">
            <h2 id="quick-actions" className="sr-only">
              Quick actions
            </h2>
            <ul className="grid gap-3 sm:grid-cols-2">
              {QUICK_ACTIONS.map((a) => {
                const Icon = a.icon
                return (
                  <li key={a.href}>
                    <Link
                      href={a.href}
                      className="group flex items-center gap-4 rounded-2xl border border-border bg-card p-4 transition-colors hover:border-primary/40"
                    >
                      <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-accent text-accent-foreground">
                        <Icon className="size-5" aria-hidden="true" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block text-sm font-medium">{a.label}</span>
                        <span className="block text-xs text-muted-foreground">{a.desc}</span>
                      </span>
                      <ArrowRight
                        className="size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5"
                        aria-hidden="true"
                      />
                    </Link>
                  </li>
                )
              })}
            </ul>
          </section>
        </div>

        <div className="flex flex-col gap-6">
          <Card>
            <div className="flex items-center justify-between">
              <h2 className="font-semibold">Your profile</h2>
              <span className="font-mono text-sm tabular-nums text-muted-foreground">{hydrated ? `${completeness}%` : '–'}</span>
            </div>
            <div
              className="mt-3 h-2 overflow-hidden rounded-full bg-muted"
              role="progressbar"
              aria-valuenow={completeness}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-label="Profile completeness"
            >
              <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${hydrated ? completeness : 0}%` }} />
            </div>
            <ul className="mt-4 flex flex-col gap-2">
              {profileChecks(profile).map((c) => (
                <li key={c.label} className="flex items-center gap-2 text-sm">
                  {hydrated && c.done ? (
                    <CheckCircle2 className="size-4 text-primary" aria-hidden="true" />
                  ) : (
                    <Circle className="size-4 text-muted-foreground" aria-hidden="true" />
                  )}
                  <span className={cn(hydrated && c.done ? 'text-muted-foreground line-through' : '')}>{c.label}</span>
                </li>
              ))}
            </ul>
            <p className="mt-4 text-xs text-muted-foreground">
              A complete profile pre-fills your IPI, PRO and publisher on every new sheet.
            </p>
            <Button
              nativeButton={false}
              render={<Link href="/dashboard/settings" />}
              variant="outline"
              size="sm"
              className="mt-4 w-full rounded-full"
            >
              {completeness === 100 ? 'Edit profile' : 'Complete profile'}
            </Button>
          </Card>

          <Card>
            <h2 className="font-semibold">Needs attention</h2>
            {!hydrated ? (
              <div className="mt-4 h-20 animate-pulse rounded-2xl bg-muted" />
            ) : needsAttention.length === 0 ? (
              <p className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="size-4 text-primary" aria-hidden="true" />
                All sheets are complete.
              </p>
            ) : (
              <ul className="mt-3 flex flex-col gap-2">
                {needsAttention.slice(0, 4).map(({ sheet, issues }) => (
                  <li key={sheet.id}>
                    <Link
                      href={`/dashboard/sheets/${sheet.id}`}
                      className="flex items-start gap-3 rounded-xl border border-border p-3 transition-colors hover:bg-secondary/60"
                    >
                      <AlertCircle className="mt-0.5 size-4 shrink-0 text-destructive" aria-hidden="true" />
                      <span className="min-w-0">
                        <span className="block truncate text-sm font-medium">{sheet.song.title.trim() || 'Untitled sheet'}</span>
                        <span className="block truncate text-xs text-muted-foreground">
                          {issues[0]}
                          {issues.length > 1 ? ` · +${issues.length - 1} more` : ''}
                        </span>
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>
    </PageContainer>
  )
}
