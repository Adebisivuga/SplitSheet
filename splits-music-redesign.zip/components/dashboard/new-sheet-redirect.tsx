'use client'

import { useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { Loader2 } from 'lucide-react'
import { createSheet } from '@/lib/sheets-store'

export function NewSheetRedirect() {
  const router = useRouter()
  const created = useRef(false)

  useEffect(() => {
    if (created.current) return
    created.current = true
    const sheet = createSheet()
    router.replace(`/dashboard/sheets/${sheet.id}`)
  }, [router])

  return (
    <div className="flex min-h-[60dvh] items-center justify-center gap-2 text-sm text-muted-foreground" role="status">
      <Loader2 className="size-4 animate-spin" aria-hidden="true" />
      Creating your sheet…
    </div>
  )
}
