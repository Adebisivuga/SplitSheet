'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { CheckCircle2, ChevronLeft, Clock, Copy, Download, Lock, ShieldAlert, XCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { SplitSheetPreview } from '@/components/builder/split-sheet-preview'
import { cn } from '@/lib/utils'
import { initials, swatchFor } from '@/lib/splits'
import { cancelRemoval, duplicateSheet, requestRemoval, type SavedSheet } from '@/lib/sheets-store'

const formatDate = (iso: string) => new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })

export function SignedSheetView({ sheet }: { sheet: SavedSheet }) {
  const router = useRouter()
  const title = sheet.song.title.trim() || 'Untitled sheet'
  const lastSigned = Object.values(sheet.signatures ?? {}).sort().at(-1)

  return (
    <section className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:py-12">
      <div className="mb-8 flex flex-col gap-4 print:hidden">
        <Link
          href="/dashboard/sheets"
          className="inline-flex w-fit items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <ChevronLeft className="size-4" aria-hidden="true" />
          Split sheets
        </Link>
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div className="min-w-0">
            <h1 className="truncate text-balance text-3xl font-semibold tracking-tight sm:text-4xl">{title}</h1>
            <p className="mt-1 text-sm text-muted-foreground">{sheet.song.artist}</p>
          </div>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-accent px-3 py-1 text-xs font-medium text-accent-foreground">
            <Lock className="size-3.5" aria-hidden="true" />
            Fully signed · locked
          </span>
        </div>
      </div>

      <div className="grid gap-10 lg:grid-cols-[1fr_400px] lg:gap-12">
        <div className="flex flex-col gap-6 print:hidden">
          <div className="flex gap-3 rounded-2xl border border-primary/30 bg-primary/10 p-4 text-sm leading-relaxed">
            <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
            <p>
              Every party has signed this sheet{lastSigned ? `, most recently on ${formatDate(lastSigned)}` : ''}. To protect
              everyone on it, a signed sheet can&apos;t be edited or deleted. Duplicate it to start a new version, or ask an admin
              to remove it from your dashboard.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button onClick={() => window.print()} className="h-11 rounded-full px-5">
              <Download data-icon="inline-start" />
              Download sealed PDF
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                const id = duplicateSheet(sheet.id)
                if (id) router.push(`/dashboard/sheets/${id}`)
              }}
              className="h-11 rounded-full px-5"
            >
              <Copy data-icon="inline-start" />
              Duplicate as new draft
            </Button>
          </div>

          <div className="rounded-2xl border border-border bg-card">
            <h2 className="border-b border-border px-4 py-3 text-sm font-semibold">Signatures</h2>
            <ul className="divide-y divide-border">
              {sheet.contributors.map((c, i) => (
                <li key={c.id} className="flex items-center gap-3 px-4 py-3">
                  <span
                    className={cn('flex size-8 shrink-0 items-center justify-center rounded-full text-[11px] font-semibold', swatchFor(i))}
                    aria-hidden="true"
                  >
                    {initials(c.name)}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{c.name}</p>
                    <p className="truncate text-xs text-muted-foreground">{c.role}</p>
                  </div>
                  <span className="text-right text-xs text-muted-foreground">
                    {sheet.signatures?.[c.id] ? formatDate(sheet.signatures[c.id]) : '—'}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <RemovalPanel sheet={sheet} />
        </div>

        <aside aria-label="Signed sheet" className="print:block">
          <div className="lg:sticky lg:top-24">
            <SplitSheetPreview song={sheet.song} contributors={sheet.contributors} printable />
          </div>
        </aside>
      </div>
    </section>
  )
}

function RemovalPanel({ sheet }: { sheet: SavedSheet }) {
  const [reason, setReason] = useState('')
  const removal = sheet.removal

  if (removal?.status === 'pending') {
    return (
      <div id="removal" className="scroll-mt-24 rounded-2xl border border-chart-3/40 bg-chart-3/10 p-4">
        <div className="flex items-start gap-3">
          <Clock className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
          <div className="min-w-0 flex-1">
            <h2 className="text-sm font-semibold">Removal request pending</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Sent {formatDate(removal.requestedAt)}. An admin will review it and the sheet will disappear from your dashboard if
              approved.
            </p>
            <p className="mt-2 rounded-xl bg-background/60 p-3 text-sm">&ldquo;{removal.reason}&rdquo;</p>
            <Button size="sm" variant="ghost" className="mt-3 rounded-full" onClick={() => cancelRemoval(sheet.id)}>
              Cancel request
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <form
      id="removal"
      className="scroll-mt-24 rounded-2xl border border-border bg-card p-4"
      onSubmit={(e) => {
        e.preventDefault()
        if (reason.trim().length < 10) return
        requestRemoval(sheet.id, reason)
        setReason('')
      }}
    >
      <div className="flex items-start gap-3">
        <ShieldAlert className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
        <div className="min-w-0 flex-1">
          <h2 className="text-sm font-semibold">Request removal</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Signed sheets can only be taken off your dashboard after an admin approves it.
          </p>
          {removal?.status === 'rejected' && (
            <p className="mt-3 flex items-center gap-2 text-sm text-destructive">
              <XCircle className="size-4" aria-hidden="true" />
              Your previous request was declined{removal.resolvedAt ? ` on ${formatDate(removal.resolvedAt)}` : ''}.
            </p>
          )}
          <label htmlFor="removal-reason" className="mt-3 block text-sm font-medium">
            Reason
          </label>
          <textarea
            id="removal-reason"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            rows={3}
            minLength={10}
            required
            placeholder="e.g. Replaced by a newer version after the remix was released."
            className="mt-1.5 w-full resize-none rounded-xl border border-input bg-background px-3 py-2 text-sm outline-none placeholder:text-muted-foreground focus-visible:ring-3 focus-visible:ring-ring/40"
          />
          <Button type="submit" variant="outline" disabled={reason.trim().length < 10} className="mt-3 rounded-full">
            Send to admin
          </Button>
        </div>
      </div>
    </form>
  )
}
