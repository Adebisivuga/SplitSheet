'use client'

import Link from 'next/link'
import { useMemo, useState } from 'react'
import { Clock, Copy, FileText, Lock, Pencil, Plus, Search, ShieldAlert, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { PageContainer, PageHeader } from '@/components/app/page-header'
import { cn } from '@/lib/utils'
import {
  canDelete,
  deleteSheet,
  duplicateSheet,
  signedCount,
  STATUS_LABEL,
  useHydrated,
  useSheets,
  type SavedSheet,
} from '@/lib/sheets-store'
import { initials, swatchFor } from '@/lib/splits'

type Filter = 'all' | 'draft' | 'ready' | 'signed'

const FILTERS: { key: Filter; label: string }[] = [
  { key: 'all', label: 'All' },
  { key: 'draft', label: 'Drafts' },
  { key: 'ready', label: 'Ready to sign' },
  { key: 'signed', label: 'Signed' },
]

export function SheetsDashboard() {
  const hydrated = useHydrated()
  const sheets = useSheets()
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState<Filter>('all')

  const sorted = useMemo(() => [...sheets].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)), [sheets])

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase()
    return sorted.filter((s) => {
      if (filter !== 'all' && s.status !== filter) return false
      if (!q) return true
      return [s.song.title, s.song.artist, ...s.contributors.map((c) => c.name)].some((v) => v.toLowerCase().includes(q))
    })
  }, [sorted, query, filter])

  const stats = useMemo(() => {
    return [
      { label: 'Total sheets', value: sheets.length },
      { label: 'Drafts', value: sheets.filter((s) => s.status === 'draft').length },
      { label: 'Ready to sign', value: sheets.filter((s) => s.status === 'ready').length },
      { label: 'Fully signed', value: sheets.filter((s) => s.status === 'signed').length },
    ]
  }, [sheets])

  return (
    <PageContainer>
      <PageHeader
        eyebrow={
          <>
            <Lock className="size-3.5" aria-hidden="true" />
            Private to you
          </>
        }
        title="Split sheets"
        description="Only you can open and preview these sheets."
        actions={
          <Button nativeButton={false} render={<Link href="/dashboard/sheets/new" />} className="h-10 rounded-full px-4">
            <Plus data-icon="inline-start" />
            New sheet
          </Button>
        }
      />

      <dl className="mt-8 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {stats.map((stat) => (
          <div key={stat.label} className="rounded-2xl border border-border bg-card p-4">
            <dt className="text-xs font-medium text-muted-foreground">{stat.label}</dt>
            <dd className="mt-1 font-mono text-2xl font-semibold tabular-nums">{hydrated ? stat.value : '–'}</dd>
          </div>
        ))}
      </dl>

      <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div role="tablist" aria-label="Filter sheets" className="flex gap-1 overflow-x-auto rounded-full bg-muted p-1">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              type="button"
              role="tab"
              aria-selected={filter === f.key}
              onClick={() => setFilter(f.key)}
              className={cn(
                'shrink-0 rounded-full px-4 py-1.5 text-sm font-medium transition-colors',
                filter === f.key ? 'bg-background text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground',
              )}
            >
              {f.label}
            </button>
          ))}
        </div>
        <label className="relative sm:w-72">
          <span className="sr-only">Search sheets</span>
          <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search songs or people"
            className="h-10 w-full rounded-full border border-input bg-card pl-10 pr-4 text-sm outline-none transition-shadow placeholder:text-muted-foreground focus-visible:ring-3 focus-visible:ring-ring/40"
          />
        </label>
      </div>

      <div className="mt-6">
        {!hydrated ? (
          <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3" aria-hidden="true">
            {[0, 1, 2].map((i) => (
              <li key={i} className="h-52 animate-pulse rounded-3xl border border-border bg-card" />
            ))}
          </ul>
        ) : sheets.length === 0 ? (
          <EmptyState />
        ) : visible.length === 0 ? (
          <p className="rounded-3xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
            No sheets match your search.
          </p>
        ) : (
          <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {visible.map((sheet) => (
              <SheetCard key={sheet.id} sheet={sheet} />
            ))}
          </ul>
        )}
      </div>

    </PageContainer>
  )
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center gap-4 rounded-3xl border border-dashed border-border bg-card/60 px-6 py-16 text-center">
      <span className="flex size-12 items-center justify-center rounded-2xl bg-accent text-accent-foreground">
        <FileText className="size-6" aria-hidden="true" />
      </span>
      <div>
        <h2 className="font-semibold">No split sheets yet</h2>
        <p className="mt-1 max-w-sm text-sm text-muted-foreground">
          Create your first sheet to agree master and publishing shares with everyone on the song.
        </p>
      </div>
      <Button nativeButton={false} render={<Link href="/dashboard/sheets/new" />} className="rounded-full">
        <Plus data-icon="inline-start" />
        Create a sheet
      </Button>
    </div>
  )
}

function SheetCard({ sheet }: { sheet: SavedSheet }) {
  const [confirming, setConfirming] = useState(false)
  const title = sheet.song.title.trim() || 'Untitled sheet'
  const locked = !canDelete(sheet)
  const signed = signedCount(sheet)
  const pendingRemoval = sheet.removal?.status === 'pending'
  const href = `/dashboard/sheets/${sheet.id}`
  const updated = new Date(sheet.updatedAt).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })

  return (
    <li className="group relative flex flex-col rounded-3xl border border-border bg-card p-5 transition-shadow hover:shadow-lg hover:shadow-foreground/5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h2 className="truncate font-semibold">
            <Link href={href} className="after:absolute after:inset-0 after:rounded-3xl focus-visible:outline-none">
              {title}
            </Link>
          </h2>
          <p className="truncate text-sm text-muted-foreground">{sheet.song.artist || 'No artist yet'}</p>
        </div>
        <span
          className={cn(
            'inline-flex shrink-0 items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium',
            sheet.status === 'draft' ? 'bg-muted text-muted-foreground' : 'bg-accent text-accent-foreground',
          )}
        >
          {locked && <Lock className="size-3" aria-hidden="true" />}
          {STATUS_LABEL[sheet.status]}
        </span>
      </div>

      {pendingRemoval ? (
        <p className="mt-3 inline-flex w-fit items-center gap-1.5 rounded-full bg-chart-3/15 px-2.5 py-1 text-xs font-medium">
          <Clock className="size-3" aria-hidden="true" />
          Removal pending admin review
        </p>
      ) : (
        sheet.status === 'ready' &&
        signed > 0 && (
          <p className="mt-3 text-xs text-muted-foreground">
            {signed} of {sheet.contributors.length} signed
          </p>
        )
      )}

      <div className="mt-5 flex flex-col gap-2.5">
        {(['master', 'publishing'] as const).map((key) => (
          <div key={key} className="flex items-center gap-3">
            <span className="w-16 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">{key}</span>
            <div className="flex h-2 flex-1 gap-0.5 overflow-hidden rounded-full bg-muted" role="img" aria-label={`${key} split`}>
              {sheet.contributors.map((c, i) =>
                c[key] > 0 ? <span key={c.id} className={cn('rounded-full', swatchFor(i))} style={{ width: `${c[key]}%` }} /> : null,
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-5 flex items-center justify-between gap-3 border-t border-border pt-4">
        <div className="flex items-center gap-2">
          <div className="flex -space-x-2" aria-label={`${sheet.contributors.length} contributors`}>
            {sheet.contributors.slice(0, 4).map((c, i) => (
              <span
                key={c.id}
                className={cn(
                  'flex size-7 items-center justify-center rounded-full border-2 border-card text-[10px] font-semibold text-foreground',
                  swatchFor(i),
                )}
                aria-hidden="true"
              >
                {initials(c.name)}
              </span>
            ))}
          </div>
          <span className="text-xs text-muted-foreground">{updated}</span>
        </div>

        <div className="relative z-10 flex items-center gap-1">
          {confirming ? (
            <>
              <Button size="sm" variant="destructive" className="rounded-full" onClick={() => deleteSheet(sheet.id)}>
                {signed > 0 ? `Delete (${signed} signed)` : 'Delete'}
              </Button>
              <Button size="sm" variant="ghost" className="rounded-full" onClick={() => setConfirming(false)}>
                Cancel
              </Button>
            </>
          ) : locked ? (
            <>
              <Button size="icon-sm" variant="ghost" aria-label={`Duplicate ${title}`} onClick={() => duplicateSheet(sheet.id)}>
                <Copy />
              </Button>
              {!pendingRemoval && (
                <Button
                  size="icon-sm"
                  variant="ghost"
                  nativeButton={false}
                  render={<Link href={`${href}#removal`} />}
                  aria-label={`Request removal of ${title}`}
                  title="Request removal (admin approval)"
                >
                  <ShieldAlert />
                </Button>
              )}
            </>
          ) : (
            <>
              <Button size="icon-sm" variant="ghost" nativeButton={false} render={<Link href={href} />} aria-label={`Edit ${title}`}>
                <Pencil />
              </Button>
              <Button size="icon-sm" variant="ghost" aria-label={`Duplicate ${title}`} onClick={() => duplicateSheet(sheet.id)}>
                <Copy />
              </Button>
              <Button size="icon-sm" variant="ghost" aria-label={`Delete ${title}`} onClick={() => setConfirming(true)}>
                <Trash2 />
              </Button>
            </>
          )}
        </div>
      </div>
    </li>
  )
}

