'use client'

import { useState } from 'react'
import { Check, Download, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, Field, inputClass } from '@/components/app/form-field'
import { PageContainer, PageHeader } from '@/components/app/page-header'
import { cn } from '@/lib/utils'
import { isValidIpi, normalizeIpi, PROS, ROLES } from '@/lib/splits'
import { clearSheets, useHydrated, useSheets } from '@/lib/sheets-store'
import { clearProfile, saveProfile, useProfile, type Profile } from '@/lib/profile-store'
import { clearCollaborators, useCollaborators } from '@/lib/collaborators-store'

export function Settings() {
  const hydrated = useHydrated()
  if (!hydrated) {
    return (
      <PageContainer>
        <div className="h-96 animate-pulse rounded-3xl bg-muted" />
      </PageContainer>
    )
  }
  return <SettingsForm />
}

function SettingsForm() {
  const profile = useProfile()
  const sheets = useSheets()
  const collaborators = useCollaborators()
  const [form, setForm] = useState<Profile>(profile)
  const [saved, setSaved] = useState(false)
  const [confirmReset, setConfirmReset] = useState(false)

  const set = <K extends keyof Profile>(key: K, value: Profile[K]) => {
    setSaved(false)
    setForm((f) => ({ ...f, [key]: value }))
  }

  const ipiError = form.ipi && !isValidIpi(form.ipi) ? 'IPI must be 9–11 digits' : undefined
  const pubIpiError = form.publisherIpi && !isValidIpi(form.publisherIpi) ? 'IPI must be 9–11 digits' : undefined

  function exportData() {
    const blob = new Blob([JSON.stringify({ profile, sheets, collaborators }, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'splits-music-backup.json'
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <PageContainer>
      <PageHeader
        eyebrow="Settings"
        title="Profile & settings"
        description="Your writer and publisher details. These pre-fill your row on every new split sheet."
      />

      <form
        className="mt-8 flex flex-col gap-6"
        onSubmit={(e) => {
          e.preventDefault()
          if (ipiError || pubIpiError) return
          saveProfile(form)
          setSaved(true)
        }}
      >
        <Card>
          <h2 className="font-semibold">About you</h2>
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <Field id="p-name" label="Full legal name">
              <input id="p-name" className={inputClass} value={form.name} onChange={(e) => set('name', e.target.value)} autoComplete="name" />
            </Field>
            <Field id="p-email" label="Email">
              <input id="p-email" type="email" className={inputClass} value={form.email} onChange={(e) => set('email', e.target.value)} autoComplete="email" />
            </Field>
            <Field id="p-artist" label="Artist name" hint="Used as the main artist on new sheets">
              <input id="p-artist" className={inputClass} value={form.artistName} onChange={(e) => set('artistName', e.target.value)} />
            </Field>
            <Field id="p-role" label="Usual role">
              <select id="p-role" className={inputClass} value={form.role} onChange={(e) => set('role', e.target.value)}>
                {ROLES.map((r) => (
                  <option key={r}>{r}</option>
                ))}
              </select>
            </Field>
          </div>
        </Card>

        <Card>
          <h2 className="font-semibold">Writer registration</h2>
          <p className="mt-1 text-sm text-muted-foreground">Your IPI / CAE number and the collection society you belong to.</p>
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <Field id="p-ipi" label="Writer IPI / CAE" hint="9–11 digits" error={ipiError}>
              <input id="p-ipi" inputMode="numeric" className={cn(inputClass, 'font-mono')} value={form.ipi} onChange={(e) => set('ipi', normalizeIpi(e.target.value))} aria-invalid={!!ipiError} />
            </Field>
            <Field id="p-pro" label="PRO / society">
              <input id="p-pro" list="settings-pro-list" className={inputClass} value={form.pro} onChange={(e) => set('pro', e.target.value)} />
            </Field>
          </div>
        </Card>

        <Card>
          <h2 className="font-semibold">Publisher</h2>
          <p className="mt-1 text-sm text-muted-foreground">The publisher that administers your share of the songs.</p>
          <div className="mt-5 grid gap-4 sm:grid-cols-3">
            <Field id="p-pub" label="Publisher name">
              <input id="p-pub" className={inputClass} value={form.publisherName} onChange={(e) => set('publisherName', e.target.value)} />
            </Field>
            <Field id="p-pub-ipi" label="Publisher IPI" hint="9–11 digits" error={pubIpiError}>
              <input id="p-pub-ipi" inputMode="numeric" className={cn(inputClass, 'font-mono')} value={form.publisherIpi} onChange={(e) => set('publisherIpi', normalizeIpi(e.target.value))} aria-invalid={!!pubIpiError} />
            </Field>
            <Field id="p-pub-pro" label="Publisher society">
              <input id="p-pub-pro" list="settings-pro-list" className={inputClass} value={form.publisherPro} onChange={(e) => set('publisherPro', e.target.value)} />
            </Field>
          </div>
          <datalist id="settings-pro-list">
            {PROS.map((p) => (
              <option key={p} value={p} />
            ))}
          </datalist>
        </Card>

        <Card>
          <label className="flex cursor-pointer items-start justify-between gap-4">
            <span>
              <span className="block font-semibold">Pre-fill new sheets</span>
              <span className="mt-1 block text-sm text-muted-foreground">
                Add yourself as the first contributor with these details whenever you start a sheet.
              </span>
            </span>
            <input
              type="checkbox"
              role="switch"
              checked={form.prefill}
              onChange={(e) => set('prefill', e.target.checked)}
              className="peer sr-only"
            />
            <span
              aria-hidden="true"
              className="relative mt-1 h-6 w-11 shrink-0 rounded-full bg-muted transition-colors after:absolute after:left-0.5 after:top-0.5 after:size-5 after:rounded-full after:bg-background after:shadow after:transition-transform peer-checked:bg-primary peer-checked:after:translate-x-5 peer-focus-visible:ring-3 peer-focus-visible:ring-ring/40"
            />
          </label>
        </Card>

        <div className="sticky bottom-24 z-10 flex items-center justify-end gap-3 lg:bottom-6">
          <p aria-live="polite" className="text-sm text-muted-foreground">
            {saved && (
              <span className="inline-flex items-center gap-1">
                <Check className="size-4 text-primary" aria-hidden="true" />
                Saved
              </span>
            )}
          </p>
          <Button type="submit" className="h-10 rounded-full px-6 shadow-lg shadow-primary/20">
            Save profile
          </Button>
        </div>
      </form>

      <Card className="mt-10">
        <h2 className="font-semibold">Your data</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Sheets, collaborators and your profile are stored privately in this browser.
        </p>
        <div className="mt-5 flex flex-wrap gap-2">
          <Button variant="outline" className="rounded-full" onClick={exportData}>
            <Download data-icon="inline-start" />
            Download backup
          </Button>
          {confirmReset ? (
            <>
              <Button
                variant="destructive"
                className="rounded-full"
                onClick={() => {
                  clearSheets()
                  clearCollaborators()
                  clearProfile()
                  setConfirmReset(false)
                  setForm({ ...profile, name: '', email: '', artistName: '', ipi: '', pro: '', publisherName: '', publisherIpi: '', publisherPro: '' })
                }}
              >
                Yes, delete everything
              </Button>
              <Button variant="ghost" className="rounded-full" onClick={() => setConfirmReset(false)}>
                Cancel
              </Button>
            </>
          ) : (
            <Button variant="ghost" className="rounded-full text-destructive" onClick={() => setConfirmReset(true)}>
              <Trash2 data-icon="inline-start" />
              Delete all data
            </Button>
          )}
        </div>
      </Card>
    </PageContainer>
  )
}
