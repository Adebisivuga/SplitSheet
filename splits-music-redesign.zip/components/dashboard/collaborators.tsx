'use client'

import { useMemo, useState } from 'react'
import { Download, Pencil, Plus, Search, Trash2, Users, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, Field, inputClass } from '@/components/app/form-field'
import { PageContainer, PageHeader } from '@/components/app/page-header'
import { cn } from '@/lib/utils'
import { initials, isValidIpi, normalizeIpi, PROS, ROLES, swatchFor } from '@/lib/splits'
import { useHydrated, useSheets } from '@/lib/sheets-store'
import {
  collaboratorKey,
  deleteCollaborator,
  saveCollaborator,
  toCollaborator,
  useCollaborators,
  type Collaborator,
} from '@/lib/collaborators-store'

const blank = (): Collaborator => ({
  id: Math.random().toString(36).slice(2, 10),
  name: '',
  role: 'Co-writer',
  email: '',
  ipi: '',
  pro: '',
  publisherName: '',
  publisherIpi: '',
  publisherPro: '',
})

export function Collaborators() {
  const hydrated = useHydrated()
  const collaborators = useCollaborators()
  const sheets = useSheets()
  const [editing, setEditing] = useState<Collaborator | null>(null)
  const [query, setQuery] = useState('')

  const known = useMemo(() => new Set(collaborators.map((c) => collaboratorKey(c.name))), [collaborators])
  const importable = useMemo(() => {
    const seen = new Set<string>()
    return sheets
      .flatMap((s) => s.contributors)
      .filter((c) => {
        const key = collaboratorKey(c.name)
        if (!key || known.has(key) || seen.has(key)) return false
        seen.add(key)
        return true
      })
  }, [sheets, known])

  const sheetCount = useMemo(() => {
    const counts = new Map<string, number>()
    sheets.forEach((s) =>
      new Set(s.contributors.map((c) => collaboratorKey(c.name))).forEach((k) => counts.set(k, (counts.get(k) ?? 0) + 1)),
    )
    return counts
  }, [sheets])

  const visible = collaborators.filter((c) => {
    const q = query.trim().toLowerCase()
    return !q || [c.name, c.role, c.pro, c.publisherName].some((v) => v.toLowerCase().includes(q))
  })

  return (
    <PageContainer>
      <PageHeader
        eyebrow="Collaborators"
        title="Your people"
        description="Save writers, producers and publishers once with their IPI and PRO — then add them to any sheet in one click."
        actions={
          <>
            {hydrated && importable.length > 0 && (
              <Button
                variant="outline"
                className="h-10 rounded-full px-4"
                onClick={() => importable.forEach((c) => saveCollaborator({ ...toCollaborator(c), id: blank().id }))}
              >
                <Download data-icon="inline-start" />
                Import {importable.length} from sheets
              </Button>
            )}
            <Button className="h-10 rounded-full px-4" onClick={() => setEditing(blank())}>
              <Plus data-icon="inline-start" />
              Add collaborator
            </Button>
          </>
        }
      />

      {editing && <CollaboratorForm key={editing.id} initial={editing} onClose={() => setEditing(null)} />}

      <label className="relative mt-8 block sm:w-80">
        <span className="sr-only">Search collaborators</span>
        <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search name, role, PRO or publisher"
          className="h-10 w-full rounded-full border border-input bg-card pl-10 pr-4 text-sm outline-none placeholder:text-muted-foreground focus-visible:ring-3 focus-visible:ring-ring/40"
        />
      </label>

      <div className="mt-5">
        {!hydrated ? (
          <div className="h-40 animate-pulse rounded-3xl bg-muted" />
        ) : collaborators.length === 0 ? (
          <div className="flex flex-col items-center gap-3 rounded-3xl border border-dashed border-border bg-card/60 px-6 py-16 text-center">
            <Users className="size-7 text-muted-foreground" aria-hidden="true" />
            <p className="max-w-sm text-sm text-muted-foreground">
              No saved collaborators yet. Add someone, or import everyone from your existing sheets.
            </p>
          </div>
        ) : visible.length === 0 ? (
          <p className="rounded-3xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
            No collaborators match your search.
          </p>
        ) : (
          <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {visible.map((c, i) => {
              const complete = isValidIpi(c.ipi) && !!c.pro && !!c.publisherName && isValidIpi(c.publisherIpi) && !!c.publisherPro
              const count = sheetCount.get(collaboratorKey(c.name)) ?? 0
              return (
                <li key={c.id} className="flex flex-col rounded-3xl border border-border bg-card p-5">
                  <div className="flex items-start gap-3">
                    <span
                      className={cn(
                        'flex size-10 shrink-0 items-center justify-center rounded-full text-xs font-semibold text-foreground',
                        swatchFor(i),
                      )}
                      aria-hidden="true"
                    >
                      {initials(c.name)}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-medium">{c.name || 'Unnamed'}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {c.role} · on {count} {count === 1 ? 'sheet' : 'sheets'}
                      </p>
                    </div>
                    <span
                      className={cn(
                        'shrink-0 rounded-full px-2 py-0.5 text-[11px] font-medium',
                        complete ? 'bg-accent text-accent-foreground' : 'bg-muted text-muted-foreground',
                      )}
                    >
                      {complete ? 'Complete' : 'Incomplete'}
                    </span>
                  </div>
                  <dl className="mt-4 grid grid-cols-2 gap-x-3 gap-y-2 text-xs">
                    <div>
                      <dt className="text-muted-foreground">Writer IPI</dt>
                      <dd className="font-mono">{c.ipi || '—'}</dd>
                    </div>
                    <div>
                      <dt className="text-muted-foreground">PRO</dt>
                      <dd>{c.pro || '—'}</dd>
                    </div>
                    <div className="col-span-2">
                      <dt className="text-muted-foreground">Publisher</dt>
                      <dd className="truncate">
                        {c.publisherName || '—'}
                        {c.publisherIpi && <span className="font-mono text-muted-foreground"> · {c.publisherIpi}</span>}
                      </dd>
                    </div>
                  </dl>
                  <div className="mt-4 flex gap-1 border-t border-border pt-3">
                    <Button size="sm" variant="ghost" className="rounded-full" onClick={() => setEditing(c)}>
                      <Pencil data-icon="inline-start" />
                      Edit
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="rounded-full text-muted-foreground"
                      onClick={() => deleteCollaborator(c.id)}
                      aria-label={`Remove ${c.name}`}
                    >
                      <Trash2 data-icon="inline-start" />
                      Remove
                    </Button>
                  </div>
                </li>
              )
            })}
          </ul>
        )}
      </div>
    </PageContainer>
  )
}

function CollaboratorForm({ initial, onClose }: { initial: Collaborator; onClose: () => void }) {
  const [form, setForm] = useState(initial)
  const [submitted, setSubmitted] = useState(false)
  const set = <K extends keyof Collaborator>(key: K, value: Collaborator[K]) => setForm((f) => ({ ...f, [key]: value }))

  const ipiError = submitted && form.ipi && !isValidIpi(form.ipi) ? 'IPI must be 9–11 digits' : undefined
  const pubIpiError = submitted && form.publisherIpi && !isValidIpi(form.publisherIpi) ? 'IPI must be 9–11 digits' : undefined

  return (
    <Card className="mt-6 animate-in fade-in slide-in-from-top-2">
      <form
        onSubmit={(e) => {
          e.preventDefault()
          setSubmitted(true)
          if (!form.name.trim() || ipiError || (form.ipi && !isValidIpi(form.ipi)) || (form.publisherIpi && !isValidIpi(form.publisherIpi))) return
          saveCollaborator({ ...form, name: form.name.trim() })
          onClose()
        }}
      >
        <div className="flex items-center justify-between">
          <h2 className="font-semibold">{initial.name ? `Edit ${initial.name}` : 'New collaborator'}</h2>
          <Button type="button" size="icon-sm" variant="ghost" aria-label="Close form" onClick={onClose}>
            <X />
          </Button>
        </div>
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Field id="c-name" label="Full legal name" error={submitted && !form.name.trim() ? 'Name is required' : undefined}>
            <input id="c-name" className={inputClass} value={form.name} onChange={(e) => set('name', e.target.value)} aria-invalid={submitted && !form.name.trim()} />
          </Field>
          <Field id="c-role" label="Role">
            <select id="c-role" className={inputClass} value={form.role} onChange={(e) => set('role', e.target.value)}>
              {ROLES.map((r) => (
                <option key={r}>{r}</option>
              ))}
            </select>
          </Field>
          <Field id="c-email" label="Email">
            <input id="c-email" type="email" className={inputClass} value={form.email} onChange={(e) => set('email', e.target.value)} />
          </Field>
          <Field id="c-ipi" label="Writer IPI / CAE" hint="9–11 digits" error={ipiError}>
            <input id="c-ipi" inputMode="numeric" className={cn(inputClass, 'font-mono')} value={form.ipi} onChange={(e) => set('ipi', normalizeIpi(e.target.value))} aria-invalid={!!ipiError} />
          </Field>
          <Field id="c-pro" label="PRO / society">
            <input id="c-pro" list="pro-list" className={inputClass} value={form.pro} onChange={(e) => set('pro', e.target.value)} />
          </Field>
          <div className="hidden lg:block" />
          <Field id="c-pub" label="Publisher name">
            <input id="c-pub" className={inputClass} value={form.publisherName} onChange={(e) => set('publisherName', e.target.value)} />
          </Field>
          <Field id="c-pub-ipi" label="Publisher IPI" hint="9–11 digits" error={pubIpiError}>
            <input id="c-pub-ipi" inputMode="numeric" className={cn(inputClass, 'font-mono')} value={form.publisherIpi} onChange={(e) => set('publisherIpi', normalizeIpi(e.target.value))} aria-invalid={!!pubIpiError} />
          </Field>
          <Field id="c-pub-pro" label="Publisher society">
            <input id="c-pub-pro" list="pro-list" className={inputClass} value={form.publisherPro} onChange={(e) => set('publisherPro', e.target.value)} />
          </Field>
        </div>
        <datalist id="pro-list">
          {PROS.map((p) => (
            <option key={p} value={p} />
          ))}
        </datalist>
        <div className="mt-6 flex justify-end gap-2">
          <Button type="button" variant="ghost" className="rounded-full" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" className="rounded-full px-5">
            Save collaborator
          </Button>
        </div>
      </form>
    </Card>
  )
}
