'use client'

import Link from 'next/link'
import { useMemo, useState } from 'react'
import { Calculator } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, Field, inputClass } from '@/components/app/form-field'
import { PageContainer, PageHeader } from '@/components/app/page-header'
import { cn } from '@/lib/utils'
import { swatchFor, total, type ShareKey } from '@/lib/splits'
import { useHydrated, useSheets } from '@/lib/sheets-store'

const CURRENCIES = ['USD', 'NGN', 'GBP', 'EUR', 'GHS', 'KES', 'ZAR', 'CAD'] as const

const INCOME: { key: ShareKey; label: string; desc: string }[] = [
  { key: 'master', label: 'Master income', desc: 'Streaming, sales & sync of the recording' },
  { key: 'publishing', label: 'Publishing income', desc: 'Performance & mechanical royalties' },
]

export function Royalties() {
  const hydrated = useHydrated()
  const sheets = useSheets()
  const [sheetId, setSheetId] = useState('')
  const [amount, setAmount] = useState('1000')
  const [currency, setCurrency] = useState<(typeof CURRENCIES)[number]>('USD')
  const [income, setIncome] = useState<ShareKey>('master')

  const sheet = sheets.find((s) => s.id === sheetId) ?? sheets[0]
  const value = Math.max(0, Number(amount) || 0)
  const fmt = useMemo(() => new Intl.NumberFormat(undefined, { style: 'currency', currency }), [currency])

  const payouts = useMemo(() => {
    if (!sheet) return []
    return sheet.contributors
      .map((c, i) => ({ c, i, share: c[income], payout: (value * c[income]) / 100 }))
      .filter((p) => p.share > 0)
      .sort((a, b) => b.share - a.share)
  }, [sheet, income, value])

  const shareTotal = sheet ? total(sheet.contributors, income) : 0

  return (
    <PageContainer>
      <PageHeader
        eyebrow="Royalties"
        title="Royalty calculator"
        description="Enter what a song earned and see exactly how much each person should receive, based on the agreed split sheet."
      />

      {!hydrated ? (
        <div className="mt-8 h-72 animate-pulse rounded-3xl bg-muted" />
      ) : sheets.length === 0 ? (
        <div className="mt-8 flex flex-col items-center gap-3 rounded-3xl border border-dashed border-border bg-card/60 px-6 py-16 text-center">
          <Calculator className="size-7 text-muted-foreground" aria-hidden="true" />
          <p className="text-sm text-muted-foreground">Create a split sheet first to calculate payouts.</p>
          <Button nativeButton={false} render={<Link href="/dashboard/sheets/new" />} size="sm" className="rounded-full">
            Create a sheet
          </Button>
        </div>
      ) : (
        <div className="mt-8 grid gap-6 lg:grid-cols-[360px_1fr]">
          <Card className="flex flex-col gap-5 self-start">
            <Field id="r-sheet" label="Song">
              <select id="r-sheet" className={inputClass} value={sheet?.id} onChange={(e) => setSheetId(e.target.value)}>
                {sheets.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.song.title.trim() || 'Untitled sheet'}
                  </option>
                ))}
              </select>
            </Field>

            <fieldset>
              <legend className="text-sm font-medium">Income type</legend>
              <div className="mt-1.5 flex flex-col gap-2">
                {INCOME.map((opt) => (
                  <label
                    key={opt.key}
                    className={cn(
                      'flex cursor-pointer items-start gap-3 rounded-2xl border p-3 transition-colors',
                      income === opt.key ? 'border-primary bg-primary/5' : 'border-border hover:bg-secondary/60',
                    )}
                  >
                    <input
                      type="radio"
                      name="income"
                      value={opt.key}
                      checked={income === opt.key}
                      onChange={() => setIncome(opt.key)}
                      className="mt-1 accent-primary"
                    />
                    <span>
                      <span className="block text-sm font-medium">{opt.label}</span>
                      <span className="block text-xs text-muted-foreground">{opt.desc}</span>
                    </span>
                  </label>
                ))}
              </div>
            </fieldset>

            <div className="grid grid-cols-[1fr_110px] gap-3">
              <Field id="r-amount" label="Amount earned">
                <input
                  id="r-amount"
                  type="number"
                  inputMode="decimal"
                  min={0}
                  step="0.01"
                  className={cn(inputClass, 'font-mono tabular-nums')}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
              </Field>
              <Field id="r-currency" label="Currency">
                <select
                  id="r-currency"
                  className={inputClass}
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value as (typeof CURRENCIES)[number])}
                >
                  {CURRENCIES.map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </Field>
            </div>
          </Card>

          <Card>
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  {INCOME.find((i) => i.key === income)?.label}
                </p>
                <p className="mt-1 font-mono text-3xl font-semibold tabular-nums sm:text-4xl">{fmt.format(value)}</p>
              </div>
              <p className="text-sm text-muted-foreground">
                {sheet?.song.title || 'Untitled sheet'} · {payouts.length} {payouts.length === 1 ? 'payee' : 'payees'}
              </p>
            </div>

            {shareTotal !== 100 && (
              <p className="mt-4 rounded-xl bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {`This sheet's ${income} shares add up to ${shareTotal}%, so payouts won't cover the full amount.`}{' '}
                <Link href={`/dashboard/sheets/${sheet?.id}`} className="font-medium underline">
                  Fix the sheet
                </Link>
              </p>
            )}

            <div className="mt-6 flex h-3 gap-0.5 overflow-hidden rounded-full bg-muted" aria-hidden="true">
              {payouts.map((p) => (
                <span key={p.c.id} className={cn('rounded-full', swatchFor(p.i))} style={{ width: `${p.share}%` }} />
              ))}
            </div>

            {payouts.length === 0 ? (
              <p className="mt-6 text-sm text-muted-foreground">Nobody holds a {income} share on this sheet yet.</p>
            ) : (
              <ul className="mt-6 divide-y divide-border">
                {payouts.map((p) => (
                  <li key={p.c.id} className="flex items-center gap-3 py-3">
                    <span className={cn('size-3 shrink-0 rounded-full', swatchFor(p.i))} aria-hidden="true" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{p.c.name || 'Unnamed contributor'}</p>
                      <p className="truncate text-xs text-muted-foreground">
                        {p.c.role}
                        {income === 'publishing' && p.c.publisherName ? ` · via ${p.c.publisherName}` : ''}
                      </p>
                    </div>
                    <span className="w-14 text-right font-mono text-sm tabular-nums text-muted-foreground">{p.share}%</span>
                    <span className="w-28 text-right font-mono text-sm font-semibold tabular-nums">{fmt.format(p.payout)}</span>
                  </li>
                ))}
              </ul>
            )}
            <p className="mt-6 text-xs text-muted-foreground">
              Estimates only. Collection societies and distributors may deduct fees before paying out.
            </p>
          </Card>
        </div>
      )}
    </PageContainer>
  )
}
