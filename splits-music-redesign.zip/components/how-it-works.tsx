import Link from 'next/link'
import { ArrowRight, FileText, Lock, Users } from 'lucide-react'
import { Button } from '@/components/ui/button'

const STEPS = [
  {
    icon: FileText,
    title: 'Add the song',
    body: 'Title, main artist, ISRC and the date the song was created.',
  },
  {
    icon: Users,
    title: 'Add every contributor',
    body: 'Their role, writer IPI, PRO, publisher and the publisher’s IPI and society, plus master and publishing shares.',
  },
  {
    icon: Lock,
    title: 'Review privately, then sign',
    body: 'Only you see the live preview of your sheets in your dashboard. Download a PDF for everyone to sign.',
  },
]

export function HowItWorks() {
  return (
    <section id="how" className="scroll-mt-20 border-y border-border bg-secondary/60">
      <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 lg:py-20">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <p className="text-sm font-medium text-primary">How it works</p>
            <h2 className="mt-2 text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
              Put every share in writing.
            </h2>
          </div>
          <Button nativeButton={false} render={<Link href="/dashboard/sheets/new" />} className="h-11 rounded-full px-5">
            Start a sheet
            <ArrowRight data-icon="inline-end" />
          </Button>
        </div>

        <ol className="mt-10 grid gap-4 md:grid-cols-3">
          {STEPS.map((step, i) => (
            <li key={step.title} className="flex flex-col gap-4 rounded-3xl border border-border bg-card p-6">
              <div className="flex items-center justify-between">
                <span className="flex size-10 items-center justify-center rounded-2xl bg-accent text-accent-foreground">
                  <step.icon className="size-5" aria-hidden="true" />
                </span>
                <span className="font-mono text-xs text-muted-foreground">0{i + 1}</span>
              </div>
              <div>
                <h3 className="font-semibold">{step.title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
