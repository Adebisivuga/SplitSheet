'use client'

import { useEffect, useState } from 'react'
import { ArrowUpRight, X } from 'lucide-react'
import { SPONSORED_ADS } from '@/lib/sponsored-ads'

const ROTATE_MS = 7000

export function PublisherAdBanner() {
  const [dismissed, setDismissed] = useState(false)
  const [index, setIndex] = useState(0)
  const [paused, setPaused] = useState(false)

  useEffect(() => {
    if (dismissed || paused) return
    const timer = setInterval(() => {
      setIndex((i) => (i + 1) % SPONSORED_ADS.length)
    }, ROTATE_MS)
    return () => clearInterval(timer)
  }, [dismissed, paused])

  if (dismissed) return null

  const ad = SPONSORED_ADS[index]

  return (
    <aside
      aria-label="Sponsored"
      className="relative bg-foreground text-background print:hidden"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocus={() => setPaused(true)}
      onBlur={() => setPaused(false)}
    >
      <div
        key={ad.id}
        className="mx-auto flex max-w-6xl items-center justify-center gap-3 px-10 py-2 text-sm animate-in fade-in duration-500"
      >
        <span className="hidden rounded-sm border border-background/30 px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-background/70 sm:inline">
          Ad · {ad.category}
        </span>
        <p className="text-pretty text-center">
          <span className="font-medium">{ad.headline}</span>{' '}
          <span className="hidden text-background/70 md:inline">{ad.tagline}</span>
        </p>
        <a
          href={ad.href}
          target="_blank"
          rel="noopener noreferrer sponsored"
          className="inline-flex shrink-0 items-center gap-1 rounded-full bg-background px-3 py-1 text-xs font-medium text-foreground transition-opacity hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-background focus-visible:ring-offset-2 focus-visible:ring-offset-foreground"
        >
          {ad.cta}
          <ArrowUpRight className="size-3.5" aria-hidden="true" />
          <span className="sr-only">(opens in a new tab)</span>
        </a>
        <div className="hidden items-center gap-1 sm:flex" role="group" aria-label="Choose ad">
          {SPONSORED_ADS.map((item, i) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setIndex(i)}
              aria-label={`Show ${item.category} ad`}
              aria-pressed={i === index}
              className={`h-1.5 rounded-full transition-all ${
                i === index ? 'w-4 bg-background' : 'w-1.5 bg-background/40 hover:bg-background/70'
              }`}
            />
          ))}
        </div>
      </div>
      <button
        type="button"
        onClick={() => setDismissed(true)}
        aria-label="Dismiss ads"
        className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full p-1.5 text-background/70 transition-colors hover:bg-background/10 hover:text-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-background"
      >
        <X className="size-4" aria-hidden="true" />
      </button>
    </aside>
  )
}
