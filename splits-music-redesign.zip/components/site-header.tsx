'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { ArrowUpRight, LayoutGrid, Menu, Plus, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export function Logo() {
  return (
    <Link href="/" className="flex items-center gap-2 font-semibold tracking-tight">
      <span aria-hidden="true" className="flex h-7 w-7 items-end gap-[3px] rounded-lg bg-foreground p-1.5">
        <span className="h-2 w-1 rounded-full bg-chart-3" />
        <span className="h-4 w-1 rounded-full bg-primary-foreground" />
        <span className="h-3 w-1 rounded-full bg-accent" />
      </span>
      <span>Splits Music</span>
    </Link>
  )
}

const NAV_LINKS = [
  { href: '/#how', label: 'How it works' },
  { href: '/#services', label: 'Services' },
  { href: '/#after', label: 'After signing' },
] as const

export function SiteHeader() {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const onDashboard = pathname.startsWith('/dashboard')

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    setOpen(false)
  }, [pathname])

  return (
    <header className="sticky top-0 z-40 px-3 pt-3 sm:px-6 print:hidden">
      <div
        className={cn(
          'mx-auto max-w-6xl rounded-2xl border transition-all duration-300',
          scrolled || open
            ? 'border-border bg-background/85 shadow-lg shadow-foreground/5 backdrop-blur-xl'
            : 'border-transparent bg-background/60 backdrop-blur-md',
        )}
      >
        <div className="flex h-14 items-center justify-between gap-4 pl-4 pr-2">
          <Logo />

          <nav aria-label="Main" className="hidden md:block">
            <ul className="flex items-center gap-1 rounded-full bg-secondary p-1 text-sm">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="block rounded-full px-4 py-1.5 text-muted-foreground transition-colors hover:bg-background hover:text-foreground"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
              <li>
                <Link
                  href="/dashboard"
                  aria-current={onDashboard ? 'page' : undefined}
                  className={cn(
                    'flex items-center gap-1.5 rounded-full px-4 py-1.5 transition-colors',
                    onDashboard
                      ? 'bg-background font-medium text-foreground shadow-sm'
                      : 'text-muted-foreground hover:bg-background hover:text-foreground',
                  )}
                >
                  <LayoutGrid className="h-3.5 w-3.5" aria-hidden="true" />
                  My sheets
                </Link>
              </li>
            </ul>
          </nav>

          <div className="flex items-center gap-1.5">
            <Link
              href="/login"
              className="hidden rounded-full px-3 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground sm:block"
            >
              Log in
            </Link>
            <Button
              nativeButton={false}
              render={<Link href="/dashboard/sheets/new" />}
              size="sm"
              className="hidden rounded-full px-4 sm:inline-flex"
            >
              <Plus className="h-4 w-4" aria-hidden="true" />
              New sheet
            </Button>
            <Button
              size="icon"
              variant="ghost"
              className="rounded-full md:hidden"
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label={open ? 'Close menu' : 'Open menu'}
              onClick={() => setOpen((v) => !v)}
            >
              {open ? <X className="h-5 w-5" aria-hidden="true" /> : <Menu className="h-5 w-5" aria-hidden="true" />}
            </Button>
          </div>
        </div>

        {open && (
          <nav id="mobile-menu" aria-label="Mobile" className="border-t border-border px-2 pb-3 pt-2 md:hidden">
            <ul className="flex flex-col">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    onClick={() => setOpen(false)}
                    className="flex items-center justify-between rounded-xl px-3 py-3 text-base font-medium transition-colors hover:bg-secondary"
                  >
                    {link.label}
                    <ArrowUpRight className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
                  </Link>
                </li>
              ))}
              <li>
                <Link
                  href="/dashboard"
                  onClick={() => setOpen(false)}
                  aria-current={onDashboard ? 'page' : undefined}
                  className={cn(
                    'flex items-center justify-between rounded-xl px-3 py-3 text-base font-medium transition-colors hover:bg-secondary',
                    onDashboard && 'bg-secondary',
                  )}
                >
                  <span className="flex items-center gap-2">
                    <LayoutGrid className="h-4 w-4" aria-hidden="true" />
                    My sheets
                  </span>
                  <ArrowUpRight className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
                </Link>
              </li>
            </ul>
            <Button
              nativeButton={false}
              render={<Link href="/dashboard/sheets/new" onClick={() => setOpen(false)} />}
              className="mt-2 h-11 w-full rounded-xl"
            >
              <Plus className="h-4 w-4" aria-hidden="true" />
              Start a new sheet
            </Button>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <Button
                nativeButton={false}
                render={<Link href="/login" onClick={() => setOpen(false)} />}
                variant="outline"
                className="h-11 rounded-xl"
              >
                Log in
              </Button>
              <Button
                nativeButton={false}
                render={<Link href="/signup" onClick={() => setOpen(false)} />}
                variant="secondary"
                className="h-11 rounded-xl"
              >
                Sign up
              </Button>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}
