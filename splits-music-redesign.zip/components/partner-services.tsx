import { ArrowUpRight, Barcode, Database } from 'lucide-react'
import { cn } from '@/lib/utils'
import { ISRC_SERVICES, METADATA_SERVICES, type PartnerService } from '@/lib/partner-services'

type Props = {
  variant?: 'section' | 'compact'
  className?: string
}

const GROUPS = [
  {
    id: 'isrc',
    icon: Barcode,
    title: 'Get an ISRC',
    body: 'Every recording needs an ISRC to be tracked and paid. Buy codes from an official agency.',
    services: ISRC_SERVICES,
  },
  {
    id: 'metadata',
    icon: Database,
    title: 'Metadata & credits',
    body: 'Make sure your credits and recording data match your split sheet everywhere.',
    services: METADATA_SERVICES,
  },
]

export function PartnerServices({ variant = 'section', className }: Props) {
  const compact = variant === 'compact'

  return (
    <section
      id={compact ? undefined : 'services'}
      aria-labelledby={compact ? 'services-heading-compact' : 'services-heading'}
      className={cn(!compact && 'scroll-mt-20', className)}
    >
      <div className={cn(!compact && 'mx-auto max-w-6xl px-4 py-14 sm:px-6 lg:py-20')}>
        <div className="max-w-2xl">
          <p className="text-sm font-medium text-primary">Release services</p>
          <h2
            id={compact ? 'services-heading-compact' : 'services-heading'}
            className={cn(
              'mt-2 text-balance font-semibold tracking-tight',
              compact ? 'text-xl' : 'text-3xl sm:text-4xl',
            )}
          >
            ISRC codes and metadata, sorted.
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            These are trusted third-party services. Links open their websites in a new tab.
          </p>
        </div>

        <div className={cn('grid gap-4 lg:grid-cols-2', compact ? 'mt-5' : 'mt-10')}>
          {GROUPS.map((group) => (
            <div key={group.id} className="flex flex-col gap-5 rounded-3xl border border-border bg-card p-5 sm:p-6">
              <div className="flex items-start gap-3">
                <span className="flex size-10 shrink-0 items-center justify-center rounded-2xl bg-accent text-accent-foreground">
                  <group.icon className="size-5" aria-hidden="true" />
                </span>
                <div>
                  <h3 className="font-semibold">{group.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{group.body}</p>
                </div>
              </div>
              <ul className="flex flex-col divide-y divide-border rounded-2xl border border-border">
                {group.services.map((service) => (
                  <ServiceRow key={service.href} service={service} />
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function ServiceRow({ service }: { service: PartnerService }) {
  return (
    <li>
      <a
        href={service.href}
        target="_blank"
        rel="noopener noreferrer"
        className="group flex items-center justify-between gap-4 p-4 transition-colors first:rounded-t-2xl last:rounded-b-2xl hover:bg-muted/60 focus-visible:bg-muted/60 focus-visible:outline-none"
      >
        <div className="min-w-0">
          <p className="text-sm font-medium">{service.name}</p>
          <p className="mt-0.5 text-sm text-muted-foreground">{service.description}</p>
        </div>
        <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-foreground px-3 py-1.5 text-xs font-medium text-background transition-opacity group-hover:opacity-90">
          <span className="hidden sm:inline">{service.cta}</span>
          <ArrowUpRight className="size-3.5" aria-hidden="true" />
          <span className="sr-only sm:hidden">{service.cta}</span>
          <span className="sr-only">(opens in a new tab)</span>
        </span>
      </a>
    </li>
  )
}
