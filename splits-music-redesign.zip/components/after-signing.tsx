import { FileSignature, Landmark, Radio, Send } from 'lucide-react'

const STEPS = [
  {
    icon: FileSignature,
    title: 'Keep a signed copy.',
    body: 'Everyone gets the same PDF, with dates.',
  },
  {
    icon: Landmark,
    title: 'Record the work with the Nigerian Copyright Commission.',
    body: 'The NCC runs the national copyright registry and notification system. Check its site for current forms and fees.',
  },
  {
    icon: Radio,
    title: 'Join a collecting society.',
    body: 'Performance royalties from radio, TV, clubs and venues are collected by NCC-approved societies such as COSON. Give them these splits.',
  },
  {
    icon: Send,
    title: 'Send splits to your distributor.',
    body: 'Your distributor needs them to pay producers and features directly.',
  },
]

export function AfterSigning() {
  return (
    <section id="after" aria-labelledby="after-heading" className="mx-auto max-w-6xl scroll-mt-24 px-4 py-16 sm:px-6 lg:py-24 print:hidden">
      <div className="max-w-2xl">
        <p className="text-sm font-medium text-primary">Next steps</p>
        <h2 id="after-heading" className="mt-2 text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
          After everyone signs
        </h2>
        <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
          A signed sheet is the start. Here is how to make sure the money actually reaches every name on it.
        </p>
      </div>

      <ol className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {STEPS.map(({ icon: Icon, title, body }, i) => (
          <li key={title} className="group flex flex-col rounded-3xl border border-border bg-card p-6 transition-colors hover:border-primary/40">
            <div className="flex items-center justify-between">
              <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-accent text-accent-foreground transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                <Icon className="size-5" aria-hidden="true" />
              </span>
              <span className="font-mono text-sm text-muted-foreground">0{i + 1}</span>
            </div>
            <h3 className="mt-6 text-pretty font-semibold leading-snug">{title}</h3>
            <p className="mt-2 text-pretty text-sm leading-relaxed text-muted-foreground">{body}</p>
          </li>
        ))}
      </ol>
    </section>
  )
}
