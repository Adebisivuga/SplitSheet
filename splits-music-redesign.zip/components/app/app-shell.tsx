'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { ArrowLeft, FileText, LayoutDashboard, LogOut, MoreHorizontal, Plus, Users, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Logo } from '@/components/site-header'
import { cn } from '@/lib/utils'
import { initials } from '@/lib/splits'
import { useHydrated } from '@/lib/sheets-store'
import { useProfile } from '@/lib/profile-store'
import { APP_NAV, isActive } from './app-nav'

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const inBuilder = /^\/dashboard\/sheets\/[^/]+$/.test(pathname)
  const [moreOpen, setMoreOpen] = useState(false)

  useEffect(() => setMoreOpen(false), [pathname])

  return (
    <div className="flex min-h-dvh bg-secondary/50">
      <aside className="sticky top-0 hidden h-dvh w-64 shrink-0 flex-col border-r border-border bg-background lg:flex print:hidden">
        <div className="flex h-16 items-center px-5">
          <Logo />
        </div>
        <div className="px-3">
          <Button nativeButton={false} render={<Link href="/dashboard/sheets/new" />} className="h-10 w-full rounded-xl">
            <Plus data-icon="inline-start" />
            New split sheet
          </Button>
        </div>
        <nav aria-label="App" className="mt-5 flex-1 overflow-y-auto px-3">
          <ul className="flex flex-col gap-0.5">
            {APP_NAV.map((item) => {
              const active = isActive(pathname, item)
              const Icon = item.icon
              return (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    aria-current={active ? 'page' : undefined}
                    className={cn(
                      'flex items-center gap-3 rounded-xl px-3 py-2 text-sm transition-colors',
                      active
                        ? 'bg-secondary font-medium text-foreground'
                        : 'text-muted-foreground hover:bg-secondary/70 hover:text-foreground',
                    )}
                  >
                    <Icon className={cn('size-4', active && 'text-primary')} aria-hidden="true" />
                    {item.label}
                  </Link>
                </li>
              )
            })}
          </ul>
        </nav>
        <div className="border-t border-border p-3">
          <UserCard />
          <Link
            href="/"
            className="mt-1 flex items-center gap-3 rounded-xl px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-secondary/70 hover:text-foreground"
          >
            <ArrowLeft className="size-4" aria-hidden="true" />
            Back to website
          </Link>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-border bg-background/85 px-4 backdrop-blur-xl lg:hidden print:hidden">
          <Logo />
          <ProfileAvatarLink />
        </header>
        <main className={cn('flex-1', !inBuilder && 'pb-24 lg:pb-0')}>{children}</main>
      </div>

      {!inBuilder && (
        <nav
          aria-label="App tabs"
          className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/90 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl lg:hidden print:hidden"
        >
          <ul className="mx-auto grid max-w-md grid-cols-5 items-end px-2">
            <TabLink href="/dashboard" label="Home" icon={LayoutDashboard} active={pathname === '/dashboard'} />
            <TabLink href="/dashboard/sheets" label="Sheets" icon={FileText} active={pathname.startsWith('/dashboard/sheets')} />
            <li className="flex justify-center">
              <Link
                href="/dashboard/sheets/new"
                aria-label="New split sheet"
                className="-mt-5 flex size-14 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg shadow-primary/30 transition-transform active:scale-95"
              >
                <Plus className="size-6" aria-hidden="true" />
              </Link>
            </li>
            <TabLink
              href="/dashboard/collaborators"
              label="People"
              icon={Users}
              active={pathname.startsWith('/dashboard/collaborators')}
            />
            <li>
              <button
                type="button"
                onClick={() => setMoreOpen(true)}
                aria-expanded={moreOpen}
                aria-controls="more-menu"
                className="flex w-full flex-col items-center gap-1 py-2.5 text-[11px] font-medium text-muted-foreground"
              >
                <MoreHorizontal className="size-5" aria-hidden="true" />
                More
              </button>
            </li>
          </ul>
        </nav>
      )}

      {moreOpen && (
        <div
          className="fixed inset-0 z-50 flex flex-col bg-foreground/40 backdrop-blur-sm animate-in fade-in lg:hidden"
          onClick={() => setMoreOpen(false)}
        >
          <div
            id="more-menu"
            role="dialog"
            aria-modal="true"
            aria-label="All sections"
            onClick={(e) => e.stopPropagation()}
            onKeyDown={(e) => e.key === 'Escape' && setMoreOpen(false)}
            className="mt-auto rounded-t-3xl bg-background p-4 pb-[calc(env(safe-area-inset-bottom)+1.5rem)] animate-in slide-in-from-bottom duration-300"
          >
            <div className="mb-3 flex items-center justify-between px-1">
              <p className="font-semibold">All sections</p>
              <Button size="icon" variant="ghost" className="rounded-full" aria-label="Close" onClick={() => setMoreOpen(false)}>
                <X />
              </Button>
            </div>
            <ul className="grid grid-cols-2 gap-2">
              {APP_NAV.map((item) => {
                const Icon = item.icon
                const active = isActive(pathname, item)
                return (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      aria-current={active ? 'page' : undefined}
                      className={cn(
                        'flex flex-col gap-3 rounded-2xl border border-border p-3.5 text-sm font-medium transition-colors',
                        active ? 'bg-secondary' : 'hover:bg-secondary/70',
                      )}
                    >
                      <Icon className="size-5 text-primary" aria-hidden="true" />
                      {item.label}
                    </Link>
                  </li>
                )
              })}
            </ul>
            <Link
              href="/"
              className="mt-3 flex items-center justify-center gap-2 rounded-xl py-3 text-sm text-muted-foreground hover:text-foreground"
            >
              <LogOut className="size-4" aria-hidden="true" />
              Back to website
            </Link>
          </div>
        </div>
      )}
    </div>
  )
}

function TabLink({
  href,
  label,
  icon: Icon,
  active,
}: {
  href: string
  label: string
  icon: typeof Plus
  active: boolean
}) {
  return (
    <li>
      <Link
        href={href}
        aria-current={active ? 'page' : undefined}
        className={cn(
          'flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium transition-colors',
          active ? 'text-primary' : 'text-muted-foreground',
        )}
      >
        <Icon className="size-5" aria-hidden="true" />
        {label}
      </Link>
    </li>
  )
}

function UserCard() {
  const hydrated = useHydrated()
  const profile = useProfile()
  const name = hydrated && profile.name.trim() ? profile.name : 'Your profile'
  const sub = hydrated && profile.email ? profile.email : 'Add your IPI & PRO'

  return (
    <Link
      href="/dashboard/settings"
      className="flex items-center gap-3 rounded-xl px-2 py-2 transition-colors hover:bg-secondary/70"
    >
      <span className="flex size-9 shrink-0 items-center justify-center rounded-full bg-accent text-xs font-semibold text-accent-foreground">
        {hydrated ? initials(profile.name) : ''}
      </span>
      <span className="min-w-0">
        <span className="block truncate text-sm font-medium">{name}</span>
        <span className="block truncate text-xs text-muted-foreground">{sub}</span>
      </span>
    </Link>
  )
}

function ProfileAvatarLink() {
  const hydrated = useHydrated()
  const profile = useProfile()
  return (
    <Link
      href="/dashboard/settings"
      aria-label="Profile and settings"
      className="flex size-9 items-center justify-center rounded-full bg-accent text-xs font-semibold text-accent-foreground"
    >
      {hydrated ? initials(profile.name) : ''}
    </Link>
  )
}
