import { Calculator, Disc3, FileText, LayoutDashboard, Settings, ShieldCheck, Sparkles, Users, type LucideIcon } from 'lucide-react'

export type NavItem = { href: string; label: string; icon: LucideIcon; exact?: boolean }

export const APP_NAV: NavItem[] = [
  { href: '/dashboard', label: 'Overview', icon: LayoutDashboard, exact: true },
  { href: '/dashboard/sheets', label: 'Split sheets', icon: FileText },
  { href: '/dashboard/catalog', label: 'Catalog', icon: Disc3 },
  { href: '/dashboard/collaborators', label: 'Collaborators', icon: Users },
  { href: '/dashboard/royalties', label: 'Royalties', icon: Calculator },
  { href: '/dashboard/services', label: 'Services', icon: Sparkles },
  { href: '/dashboard/settings', label: 'Profile & settings', icon: Settings },
  { href: '/dashboard/admin', label: 'Admin', icon: ShieldCheck },
]

export function isActive(pathname: string, item: NavItem) {
  return item.exact ? pathname === item.href : pathname === item.href || pathname.startsWith(`${item.href}/`)
}
