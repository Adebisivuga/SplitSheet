'use client'

import { ArrowUpRight, Crown } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { ISRC_PURCHASE_URL } from '@/lib/partner-services'
import { Label } from '@/components/ui/label'
import { MASTER_OWNER_TYPES, type Song } from '@/lib/splits'
import { cn } from '@/lib/utils'
import { SectionHeading } from './section-heading'

type Props = {
  song: Song
  onChange: (song: Song) => void
}

type TextKey = 'title' | 'artist' | 'isrc' | 'date'

const FIELDS: { key: TextKey; label: string; placeholder: string; type?: string; optional?: boolean }[] = [
  { key: 'title', label: 'Song title', placeholder: 'e.g. Lagos Nights' },
  { key: 'artist', label: 'Main artist', placeholder: 'e.g. Tems O.' },
  { key: 'isrc', label: 'ISRC (if you have one)', placeholder: 'NG-A1B-26-00001', optional: true },
  { key: 'date', label: 'Agreement date', placeholder: '', type: 'date' },
]

export function SongDetails({ song, onChange }: Props) {
  return (
    <section aria-labelledby="song-heading">
      <SectionHeading id="song-heading" step={1} title="The song" description="The basics everyone is signing for." />
      <div className="grid gap-4 sm:grid-cols-2">
        {FIELDS.map((field) => (
          <div key={field.key} className="flex flex-col gap-2">
            <Label htmlFor={`song-${field.key}`} className="text-sm font-medium">
              {field.label}
              {field.optional && <span className="ml-1 font-normal text-muted-foreground">(optional)</span>}
            </Label>
            <Input
              id={`song-${field.key}`}
              type={field.type ?? 'text'}
              value={song[field.key]}
              placeholder={field.placeholder}
              onChange={(e) => onChange({ ...song, [field.key]: e.target.value })}
              className="h-11 rounded-xl bg-card px-3.5 text-base"
            />
            {field.key === 'isrc' && !song.isrc && (
              <a
                href={ISRC_PURCHASE_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex w-fit items-center gap-1 text-xs font-medium text-primary underline-offset-4 hover:underline"
              >
                {"Don't have one? Buy an ISRC"}
                <ArrowUpRight className="size-3.5" aria-hidden="true" />
                <span className="sr-only">(opens in a new tab)</span>
              </a>
            )}
          </div>
        ))}
      </div>

      <fieldset className="mt-6 rounded-2xl border border-border bg-card p-4 sm:p-5">
        <legend className="flex items-center gap-2 px-1 text-sm font-semibold">
          <Crown className="size-4 text-primary" aria-hidden="true" />
          Master ownership
        </legend>
        <p className="text-sm text-muted-foreground">
          Who owns the sound recording itself. This is separate from the master royalty shares below.
        </p>

        <div className="mt-4 flex flex-col gap-2">
          <Label htmlFor="song-masterOwner" className="text-sm font-medium">
            Master owner
          </Label>
          <Input
            id="song-masterOwner"
            value={song.masterOwner}
            placeholder="e.g. Tems O. or Leading Vibe Records"
            onChange={(e) => onChange({ ...song, masterOwner: e.target.value })}
            className="h-11 rounded-xl bg-background px-3.5 text-base"
          />
        </div>

        <div className="mt-4 flex flex-col gap-2">
          <span id="master-type-label" className="text-sm font-medium">
            Owner type <span className="font-normal text-muted-foreground">(optional)</span>
          </span>
          <div role="radiogroup" aria-labelledby="master-type-label" className="flex flex-wrap gap-2">
            {MASTER_OWNER_TYPES.map((type) => {
              const active = song.masterOwnerType === type
              return (
                <button
                  key={type}
                  type="button"
                  role="radio"
                  aria-checked={active}
                  onClick={() => onChange({ ...song, masterOwnerType: active ? '' : type })}
                  className={cn(
                    'rounded-full border px-3 py-1.5 text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring',
                    active
                      ? 'border-primary bg-primary text-primary-foreground'
                      : 'border-border bg-background text-foreground hover:bg-muted',
                  )}
                >
                  {type}
                </button>
              )
            })}
          </div>
        </div>
      </fieldset>
    </section>
  )
}
