import { swatchFor, type Contributor, type ShareKey, type Song } from '@/lib/splits'
import { SplitSeal } from '@/components/builder/split-seal'

function sheetReference(song: Song, contributors: Contributor[]) {
  const source = `${song.title}|${song.artist}|${song.date}|${contributors.map((c) => c.name).join(',')}`
  let hash = 0
  for (let i = 0; i < source.length; i++) hash = (hash * 31 + source.charCodeAt(i)) >>> 0
  return `SM-${hash.toString(36).toUpperCase().padStart(7, '0').slice(0, 7)}`
}

type Props = {
  song: Song
  contributors: Contributor[]
}

function formatDate(value: string) {
  if (!value) return '—'
  return new Date(`${value}T00:00:00`).toLocaleDateString('en-NG', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  })
}

function ShareBar({ label, contributors, shareKey }: { label: string; contributors: Contributor[]; shareKey: ShareKey }) {
  const sum = contributors.reduce((s, c) => s + c[shareKey], 0)
  return (
    <div>
      <div className="mb-2 flex items-center justify-between text-xs">
        <span className="font-medium uppercase tracking-wider text-muted-foreground">{label}</span>
        <span className="font-mono tabular-nums">{Math.round(sum * 100) / 100}%</span>
      </div>
      <div
        className="flex h-2.5 gap-0.5 overflow-hidden rounded-full bg-muted"
        role="img"
        aria-label={`${label} split: ${contributors.map((c) => `${c.name || 'Unnamed'} ${c[shareKey]}%`).join(', ')}`}
      >
        {contributors.map((c, i) =>
          c[shareKey] > 0 ? (
            <span
              key={c.id}
              className={`${swatchFor(i)} transition-[width] duration-300 first:rounded-l-full last:rounded-r-full`}
              style={{ width: `${Math.min(c[shareKey], 100)}%` }}
            />
          ) : null,
        )}
      </div>
    </div>
  )
}

function Detail({ label, value, mono = false, className = '' }: { label: string; value: string; mono?: boolean; className?: string }) {
  return (
    <div className={`min-w-0 ${className}`}>
      <dt className="text-muted-foreground">{label}</dt>
      <dd className={`truncate font-medium ${mono ? 'font-mono tabular-nums' : ''} ${value ? '' : 'text-muted-foreground/60'}`}>
        {value || '—'}
      </dd>
    </div>
  )
}

export function SplitSheetPreview({ song, contributors, printable = false }: Props & { printable?: boolean }) {
  return (
    <article
      id={printable ? "split-sheet" : undefined}
      aria-label="Split sheet preview"
      className="relative overflow-hidden rounded-3xl border border-border bg-card p-6 shadow-xl shadow-foreground/5 sm:p-7"
    >
      {printable ? (
        <div aria-hidden="true" data-print-only className="pointer-events-none absolute inset-0 hidden items-center justify-center print:flex">
          <span className="-rotate-[30deg] select-none whitespace-nowrap text-7xl font-black uppercase tracking-[0.2em] text-seal/[0.06]">
            Splits Music
          </span>
        </div>
      ) : null}

      <header className="flex items-start justify-between gap-4 border-b border-border pb-5">
        <div className="min-w-0">
          <p className="text-[11px] font-medium uppercase tracking-widest text-muted-foreground">Split sheet</p>
          <h3 className="mt-2 truncate text-2xl font-semibold tracking-tight">{song.title || 'Untitled song'}</h3>
          <p className="truncate text-sm text-muted-foreground">{song.artist || 'Main artist'}</p>
        </div>
        <span className="shrink-0 rounded-full bg-muted px-2.5 py-1 font-mono text-[11px] text-muted-foreground">
          {song.isrc || 'No ISRC'}
        </span>
      </header>

      <dl className="grid grid-cols-2 gap-4 border-b border-border py-5 text-sm">
        <div className="col-span-2 rounded-xl bg-muted/60 px-3.5 py-3">
          <dt className="text-xs text-muted-foreground">Master owner</dt>
          <dd className="mt-0.5 flex flex-wrap items-baseline gap-x-2 font-medium">
            <span className={song.masterOwner ? undefined : 'text-muted-foreground'}>
              {song.masterOwner || 'Not set yet'}
            </span>
            {song.masterOwnerType ? (
              <span className="text-xs font-normal text-muted-foreground">{song.masterOwnerType}</span>
            ) : null}
          </dd>
        </div>
        <div>
          <dt className="text-xs text-muted-foreground">Agreement date</dt>
          <dd className="mt-0.5 font-medium">{formatDate(song.date)}</dd>
        </div>
        <div>
          <dt className="text-xs text-muted-foreground">Contributors</dt>
          <dd className="mt-0.5 font-medium">{contributors.length}</dd>
        </div>
      </dl>

      <div className="flex flex-col gap-4 py-5">
        <ShareBar label="Master" contributors={contributors} shareKey="master" />
        <ShareBar label="Publishing" contributors={contributors} shareKey="publishing" />
      </div>

      <ul className="flex flex-col divide-y divide-border border-t border-border text-sm" aria-label="Contributors">
        {contributors.map((c, i) => (
          <li key={c.id} className="break-inside-avoid py-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex min-w-0 items-center gap-2">
                <span className={`h-2 w-2 shrink-0 rounded-full ${swatchFor(i)}`} aria-hidden="true" />
                <div className="min-w-0">
                  <p className="truncate font-medium">{c.name || 'Unnamed'}</p>
                  <p className="text-xs text-muted-foreground">{c.role}</p>
                </div>
              </div>
              <dl className="flex shrink-0 gap-4 text-right">
                <div>
                  <dt className="text-[10px] uppercase tracking-wider text-muted-foreground">Master</dt>
                  <dd className="font-mono tabular-nums">{c.master}%</dd>
                </div>
                <div>
                  <dt className="text-[10px] uppercase tracking-wider text-muted-foreground">Pub.</dt>
                  <dd className="font-mono tabular-nums">{c.publishing}%</dd>
                </div>
              </dl>
            </div>
            <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 rounded-xl bg-muted/60 p-3 text-xs">
              <Detail label="Writer IPI" value={c.ipi} mono />
              <Detail label="PRO" value={c.pro} />
              <Detail label="Publisher" value={c.publisherName} className="col-span-2" />
              <Detail label="Publisher IPI" value={c.publisherIpi} mono />
              <Detail label="Publisher society" value={c.publisherPro} />
            </dl>
          </li>
        ))}
      </ul>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {contributors.map((c) => (
          <div key={c.id} className="flex flex-col gap-1">
            <div className="h-8 border-b border-dashed border-foreground/30" />
            <p className="truncate text-xs text-muted-foreground">
              {c.name || 'Signature'} · Date
            </p>
          </div>
        ))}
      </div>

      <div className="mt-6 flex items-end justify-between gap-4">
        <p className="text-[10px] leading-relaxed text-muted-foreground">
          Prepared with Splits Music self-help templates. Not legal advice.
          {printable ? (
            <span data-print-only className="hidden print:inline">
              {' '}Ref. {sheetReference(song, contributors)}
            </span>
          ) : null}
        </p>
        {printable ? (
          <SplitSeal
            date={formatDate(song.date)}
            reference={sheetReference(song, contributors)}
            className="seal-stamp hidden size-32 shrink-0 -rotate-12 print:block"
          />
        ) : null}
      </div>
    </article>
  )
}
