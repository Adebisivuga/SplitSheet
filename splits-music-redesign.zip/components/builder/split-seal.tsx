import { useId } from 'react'

type Props = {
  date: string
  reference: string
  className?: string
}

const RING_TEXT = 'SPLITS MUSIC  •  CERTIFIED SPLIT SHEET  •  '

export function SplitSeal({ date, reference, className = '' }: Props) {
  const pathId = useId()

  return (
    <svg
      viewBox="0 0 200 200"
      role="img"
      aria-label={`Splits Music certified seal, ${date}, reference ${reference}`}
      className={`text-seal ${className}`}
    >
      <defs>
        <path id={pathId} d="M100,100 m-72,0 a72,72 0 1,1 144,0 a72,72 0 1,1 -144,0" />
      </defs>

      <g fill="none" stroke="currentColor">
        <circle cx="100" cy="100" r="95" strokeWidth="4" />
        <circle cx="100" cy="100" r="88" strokeWidth="1.25" />
        <circle cx="100" cy="100" r="58" strokeWidth="1.25" />
        <circle cx="100" cy="100" r="53" strokeWidth="0.75" strokeDasharray="2 3" />
      </g>

      <text fill="currentColor" fontSize="14.5" fontWeight="700" letterSpacing="2.4" fontFamily="ui-sans-serif, system-ui, sans-serif">
        <textPath href={`#${pathId}`} startOffset="0">
          {RING_TEXT}
        </textPath>
      </text>

      <g fill="currentColor" fontFamily="ui-sans-serif, system-ui, sans-serif" textAnchor="middle">
        <path d="M100 58 l3.2 6.6 7.3 1 -5.3 5.1 1.3 7.2 -6.5-3.4 -6.5 3.4 1.3-7.2 -5.3-5.1 7.3-1z" />
        <text x="100" y="104" fontSize="21" fontWeight="800" letterSpacing="3">
          SEALED
        </text>
        <rect x="62" y="111" width="76" height="1.25" />
        <text x="100" y="126" fontSize="8.5" fontWeight="600" letterSpacing="0.6">
          {date.toUpperCase()}
        </text>
        <text x="100" y="140" fontSize="8.5" fontFamily="ui-monospace, monospace" letterSpacing="1">
          {reference}
        </text>
      </g>
    </svg>
  )
}
