'use client'

import { AlertCircle, Check, CheckCircle2, Download, Info, Lock, PenLine } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { cn } from '@/lib/utils'
import { initials, swatchFor, type Contributor } from '@/lib/splits'
import { SectionHeading } from './section-heading'

type Props = {
  agreed: boolean
  onAgreedChange: (value: boolean) => void
  issues: string[]
  onDownload: () => void
  contributors: Contributor[]
  signatures: Record<string, string>
  onToggleSignature: (id: string) => void
}

export function AgreementStep({ agreed, onAgreedChange, issues, onDownload, contributors, signatures, onToggleSignature }: Props) {
  const ready = issues.length === 0 && agreed
  const signedTotal = contributors.filter((c) => signatures[c.id]).length

  return (
    <section aria-labelledby="agreement-heading">
      <SectionHeading
        id="agreement-heading"
        step={3}
        title="Agree & sign"
        description="Check everything, collect a signature from every contributor, then download the sealed PDF."
      />

      <div id="disclaimer" className="flex gap-3 rounded-2xl border border-chart-3/40 bg-chart-3/10 p-4 text-sm leading-relaxed">
        <Info className="mt-0.5 size-4 shrink-0 text-foreground/70" aria-hidden="true" />
        <p>
          Splits Music provides self-help templates. It is not a law firm and does not give legal advice. Have a music lawyer
          review anything involving large sums, a label or a publisher.
        </p>
      </div>

      <ul className="mt-4 flex flex-col gap-2" aria-label="Checklist">
        {issues.length === 0 ? (
          <li className="flex items-center gap-2 text-sm text-accent-foreground">
            <CheckCircle2 className="size-4 text-primary" aria-hidden="true" />
            All details complete and both columns add up to 100%.
          </li>
        ) : (
          issues.map((issue) => (
            <li key={issue} className="flex items-center gap-2 text-sm text-muted-foreground">
              <AlertCircle className="size-4 text-destructive" aria-hidden="true" />
              {issue}
            </li>
          ))
        )}
      </ul>

      <label className="mt-5 flex cursor-pointer items-start gap-3 rounded-2xl border border-border bg-card p-4 text-sm leading-relaxed">
        <Checkbox checked={agreed} onCheckedChange={(v) => onAgreedChange(Boolean(v))} className="mt-0.5 size-5" />
        <span>I understand this is a template, and every contributor has seen and agreed to these shares.</span>
      </label>

      <div className={cn('mt-5 rounded-2xl border border-border bg-card', !ready && 'opacity-60')}>
        <div className="flex items-center justify-between gap-3 border-b border-border px-4 py-3">
          <div>
            <h3 className="text-sm font-semibold">Signatures</h3>
            <p className="text-xs text-muted-foreground">
              {ready
                ? 'Once every party has signed, the sheet locks and can no longer be edited or deleted.'
                : 'Complete the checklist and confirm the agreement to start collecting signatures.'}
            </p>
          </div>
          <span className="shrink-0 rounded-full bg-muted px-2.5 py-1 font-mono text-xs tabular-nums">
            {signedTotal}/{contributors.length}
          </span>
        </div>
        <ul className="divide-y divide-border">
          {contributors.map((c, i) => {
            const signedAt = signatures[c.id]
            const name = c.name.trim() || `Contributor ${i + 1}`
            return (
              <li key={c.id} className="flex items-center gap-3 px-4 py-3">
                <span
                  className={cn('flex size-8 shrink-0 items-center justify-center rounded-full text-[11px] font-semibold', swatchFor(i))}
                  aria-hidden="true"
                >
                  {initials(c.name)}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{name}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {signedAt
                      ? `Signed ${new Date(signedAt).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })}`
                      : c.role || 'Awaiting signature'}
                  </p>
                </div>
                <Button
                  size="sm"
                  variant={signedAt ? 'secondary' : 'outline'}
                  disabled={!ready}
                  onClick={() => onToggleSignature(c.id)}
                  aria-label={signedAt ? `Undo signature for ${name}` : `Record signature for ${name}`}
                  className="rounded-full"
                >
                  {signedAt ? <Check data-icon="inline-start" /> : <PenLine data-icon="inline-start" />}
                  {signedAt ? 'Signed' : 'Sign'}
                </Button>
              </li>
            )
          })}
        </ul>
        {ready && signedTotal === contributors.length - 1 && contributors.length > 0 && (
          <p className="flex items-center gap-2 border-t border-border px-4 py-3 text-xs text-muted-foreground">
            <Lock className="size-3.5" aria-hidden="true" />
            The final signature will lock this sheet.
          </p>
        )}
      </div>

      <Button onClick={onDownload} disabled={!ready} size="lg" className="mt-5 h-12 w-full rounded-full text-base">
        <Download data-icon="inline-start" />
        Download split sheet PDF
      </Button>
    </section>
  )
}
