'use client'

import { BadgeCheck, Building2, Plus, Scale, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { isValidIpi, normalizeIpi, PROS, ROLES, swatchFor, type Contributor, type ShareKey } from '@/lib/splits'
import { SectionHeading } from './section-heading'
import { TotalBadge } from './total-badge'

type Props = {
  contributors: Contributor[]
  masterTotal: number
  publishingTotal: number
  onUpdate: (id: string, patch: Partial<Contributor>) => void
  onAdd: () => void
  onRemove: (id: string) => void
  onSplitEvenly: (key: ShareKey) => void
}

const fieldClass = 'h-11 rounded-xl bg-card px-3.5 text-base'

export function ContributorsEditor({
  contributors,
  masterTotal,
  publishingTotal,
  onUpdate,
  onAdd,
  onRemove,
  onSplitEvenly,
}: Props) {
  return (
    <section aria-labelledby="people-heading">
      <SectionHeading
        id="people-heading"
        step={2}
        title="Who worked on it"
        description="Master is who owns the recording. Publishing is who owns the lyrics and composition. Each column must add up to 100%."
      />

      <div className="mb-4 grid grid-cols-2 gap-3">
        <TotalBadge label="Master" value={masterTotal} onEven={() => onSplitEvenly('master')} />
        <TotalBadge label="Publishing" value={publishingTotal} onEven={() => onSplitEvenly('publishing')} />
      </div>

      <ol className="flex flex-col gap-3">
        {contributors.map((c, index) => (
          <li key={c.id} className="rounded-2xl border border-border bg-card p-4 sm:p-5">
            <div className="mb-4 flex items-center justify-between">
              <span className="flex items-center gap-2 text-sm font-medium">
                <span className={`h-2.5 w-2.5 rounded-full ${swatchFor(index)}`} aria-hidden="true" />
                {c.name || `Contributor ${index + 1}`}
              </span>
              <Button
                variant="ghost"
                size="icon-sm"
                onClick={() => onRemove(c.id)}
                disabled={contributors.length <= 1}
                aria-label={`Remove ${c.name || `contributor ${index + 1}`}`}
                className="text-muted-foreground hover:text-destructive"
              >
                <Trash2 />
              </Button>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="flex flex-col gap-2">
                <Label htmlFor={`name-${c.id}`}>Full legal name</Label>
                <Input
                  id={`name-${c.id}`}
                  value={c.name}
                  placeholder="As on your ID"
                  onChange={(e) => onUpdate(c.id, { name: e.target.value })}
                  className={fieldClass}
                />
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor={`role-${c.id}`}>Role</Label>
                <select
                  id={`role-${c.id}`}
                  value={c.role}
                  onChange={(e) => onUpdate(c.id, { role: e.target.value })}
                  className={`${fieldClass} w-full appearance-none border border-input bg-[url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='none' stroke='%236b7280' stroke-width='2' viewBox='0 0 24 24'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E")] bg-[position:right_0.85rem_center] bg-no-repeat pr-10 outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50`}
                >
                  {ROLES.map((role) => (
                    <option key={role}>{role}</option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col gap-2 sm:col-span-2">
                <Label htmlFor={`email-${c.id}`}>
                  Email <span className="font-normal text-muted-foreground">(for signing)</span>
                </Label>
                <Input
                  id={`email-${c.id}`}
                  type="email"
                  inputMode="email"
                  value={c.email}
                  placeholder="name@email.com"
                  onChange={(e) => onUpdate(c.id, { email: e.target.value })}
                  className={fieldClass}
                />
              </div>
              <ShareInput id={`master-${c.id}`} label="Master %" value={c.master} onChange={(v) => onUpdate(c.id, { master: v })} />
              <ShareInput
                id={`publishing-${c.id}`}
                label="Publishing %"
                value={c.publishing}
                onChange={(v) => onUpdate(c.id, { publishing: v })}
              />
            </div>

            <fieldset className="mt-5 grid gap-3 border-t border-border pt-4 sm:grid-cols-2">
              <legend className="float-left mb-1 flex w-full items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground sm:col-span-2">
                <BadgeCheck className="size-3.5" aria-hidden="true" />
                Writer registration
              </legend>
              <IpiInput
                id={`ipi-${c.id}`}
                label="Writer IPI / CAE"
                value={c.ipi}
                onChange={(v) => onUpdate(c.id, { ipi: v })}
              />
              <ProInput id={`pro-${c.id}`} label="PRO / society" value={c.pro} onChange={(v) => onUpdate(c.id, { pro: v })} />
            </fieldset>

            <fieldset className="mt-4 grid gap-3 rounded-xl bg-muted/50 p-3.5 sm:grid-cols-2">
              <legend className="float-left mb-1 flex w-full items-center gap-2 text-xs font-medium uppercase tracking-wider text-muted-foreground sm:col-span-2">
                <Building2 className="size-3.5" aria-hidden="true" />
                Publisher
              </legend>
              <div className="flex flex-col gap-2 sm:col-span-2">
                <Label htmlFor={`pub-name-${c.id}`}>Publisher name</Label>
                <Input
                  id={`pub-name-${c.id}`}
                  value={c.publisherName}
                  placeholder="e.g. Chocolate City Publishing"
                  onChange={(e) => onUpdate(c.id, { publisherName: e.target.value })}
                  className={fieldClass}
                />
              </div>
              <IpiInput
                id={`pub-ipi-${c.id}`}
                label="Publisher IPI"
                value={c.publisherIpi}
                onChange={(v) => onUpdate(c.id, { publisherIpi: v })}
              />
              <ProInput
                id={`pub-pro-${c.id}`}
                label="Publisher society"
                value={c.publisherPro}
                onChange={(v) => onUpdate(c.id, { publisherPro: v })}
              />
            </fieldset>
          </li>
        ))}
      </ol>

      <Button variant="outline" onClick={onAdd} className="mt-3 h-12 w-full rounded-2xl border-dashed text-base">
        <Plus data-icon="inline-start" />
        Add contributor
      </Button>
      <p className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
        <Scale className="size-3.5" aria-hidden="true" />
        Not everyone needs both. Producers often take master only; writers often take publishing only.
      </p>
      <datalist id="pro-options">
        {PROS.map((pro) => (
          <option key={pro} value={pro} />
        ))}
      </datalist>
    </section>
  )
}

function IpiInput({
  id,
  label,
  value,
  onChange,
}: {
  id: string
  label: string
  value: string
  onChange: (value: string) => void
}) {
  const invalid = value.length > 0 && !isValidIpi(value)
  return (
    <div className="flex flex-col gap-2">
      <Label htmlFor={id}>{label}</Label>
      <Input
        id={id}
        inputMode="numeric"
        autoComplete="off"
        value={value}
        placeholder="00123456789"
        aria-invalid={invalid || undefined}
        aria-describedby={`${id}-hint`}
        onChange={(e) => onChange(normalizeIpi(e.target.value))}
        className={`${fieldClass} font-mono tabular-nums`}
      />
      <p id={`${id}-hint`} className={`text-xs ${invalid ? 'text-destructive' : 'text-muted-foreground'}`}>
        {invalid ? 'IPI numbers are 9–11 digits' : 'From your society membership'}
      </p>
    </div>
  )
}

function ProInput({
  id,
  label,
  value,
  onChange,
}: {
  id: string
  label: string
  value: string
  onChange: (value: string) => void
}) {
  return (
    <div className="flex flex-col gap-2">
      <Label htmlFor={id}>{label}</Label>
      <Input
        id={id}
        list="pro-options"
        autoComplete="off"
        value={value}
        placeholder="e.g. COSON, ASCAP, PRS"
        onChange={(e) => onChange(e.target.value)}
        className={fieldClass}
      />
    </div>
  )
}

function ShareInput({
  id,
  label,
  value,
  onChange,
}: {
  id: string
  label: string
  value: number
  onChange: (value: number) => void
}) {
  return (
    <div className="flex flex-col gap-2">
      <Label htmlFor={id}>{label}</Label>
      <div className="relative">
        <Input
          id={id}
          type="number"
          inputMode="decimal"
          min={0}
          max={100}
          step="0.5"
          value={value === 0 ? '' : value}
          placeholder="0"
          onChange={(e) => {
            const next = Math.min(100, Math.max(0, Number(e.target.value) || 0))
            onChange(next)
          }}
          className={`${fieldClass} pr-9 font-mono tabular-nums`}
        />
        <span className="pointer-events-none absolute inset-y-0 right-3.5 flex items-center text-sm text-muted-foreground">%</span>
      </div>
    </div>
  )
}
