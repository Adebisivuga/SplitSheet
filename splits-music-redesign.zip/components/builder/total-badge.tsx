import { CheckCircle2 } from 'lucide-react'
import { cn } from '@/lib/utils'

type Props = {
  label: string
  value: number
  onEven?: () => void
}

export function TotalBadge({ label, value, onEven }: Props) {
  const complete = value === 100
  const over = value > 100
  const remaining = Math.round((100 - value) * 100) / 100

  return (
    <div
      className={cn(
        'rounded-2xl border p-3.5 transition-colors',
        complete && 'border-primary/30 bg-accent',
        over && 'border-destructive/40 bg-destructive/5',
        !complete && !over && 'border-border bg-card',
      )}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</span>
        {complete && <CheckCircle2 className="size-4 text-primary" aria-hidden="true" />}
      </div>
      <p
        className={cn(
          'mt-1 font-mono text-2xl font-semibold tabular-nums',
          complete && 'text-accent-foreground',
          over && 'text-destructive',
        )}
        aria-live="polite"
      >
        {value}%
      </p>
      <div className="mt-1 flex items-center justify-between gap-2 text-xs">
        <span className={cn('text-muted-foreground', over && 'text-destructive')}>
          {complete ? 'Balanced' : over ? `${Math.abs(remaining)}% over` : `${remaining}% left`}
        </span>
        {onEven && (
          <button
            type="button"
            onClick={onEven}
            className="font-medium text-primary underline-offset-4 hover:underline"
          >
            Split evenly
          </button>
        )}
      </div>
    </div>
  )
}
