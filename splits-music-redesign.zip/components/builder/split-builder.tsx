'use client'

import Link from 'next/link'
import { useEffect, useMemo, useRef, useState } from 'react'
import { ArrowLeft, ArrowRight, Check, ChevronLeft, Eye, Loader2, Lock, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import {
  isFullySigned,
  saveSheet,
  signedCount,
  STATUS_LABEL,
  type SavedSheet,
  type SheetStatus,
} from '@/lib/sheets-store'
import { evenShares, newContributor, sheetIssues, total, type Contributor, type ShareKey, type Song } from '@/lib/splits'
import { useCollaborators } from '@/lib/collaborators-store'
import { AgreementStep } from './agreement-step'
import { ContributorsEditor } from './contributors-editor'
import { SongDetails } from './song-details'
import { SplitSheetPreview } from './split-sheet-preview'

const STEPS = ['Song', 'People', 'Agree'] as const

function AddressBookPicker({
  existing,
  onPick,
}: {
  existing: Contributor[]
  onPick: (c: Omit<Contributor, 'master' | 'publishing'>) => void
}) {
  const collaborators = useCollaborators()
  const taken = new Set(existing.map((c) => c.name.trim().toLowerCase()))
  const available = collaborators.filter((c) => !taken.has(c.name.trim().toLowerCase()))
  if (collaborators.length === 0) return null

  return (
    <div className="flex flex-col gap-2 rounded-2xl border border-dashed border-border bg-card/60 p-3 sm:flex-row sm:items-center print:hidden">
      <label htmlFor="address-book" className="text-sm font-medium sm:shrink-0">
        Add from collaborators
      </label>
      <select
        id="address-book"
        value=""
        disabled={available.length === 0}
        onChange={(e) => {
          const pick = collaborators.find((c) => c.id === e.target.value)
          if (pick) onPick(pick)
        }}
        className="h-10 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none focus-visible:ring-3 focus-visible:ring-ring/40 disabled:opacity-60"
      >
        <option value="">{available.length ? 'Choose a saved collaborator…' : 'Everyone is already on this sheet'}</option>
        {available.map((c) => (
          <option key={c.id} value={c.id}>
            {c.name} · {c.role}
            {c.pro ? ` · ${c.pro}` : ''}
          </option>
        ))}
      </select>
    </div>
  )
}

export function SplitBuilder({ initial }: { initial: SavedSheet }) {
  const [song, setSong] = useState<Song>(initial.song)
  const [contributors, setContributors] = useState<Contributor[]>(initial.contributors)
  const [agreed, setAgreed] = useState(initial.agreed)
  const [signatures, setSignatures] = useState<Record<string, string>>(initial.signatures ?? {})
  const [step, setStep] = useState(0)
  const [saving, setSaving] = useState(false)
  const firstRender = useRef(true)
  const [previewOpen, setPreviewOpen] = useState(false)

  const masterTotal = total(contributors, 'master')
  const publishingTotal = total(contributors, 'publishing')

  const issues = useMemo(() => sheetIssues(song, contributors), [song, contributors])
  const signable = issues.length === 0 && agreed
  const signed = signedCount({ contributors, signatures })

  const status: SheetStatus = signable ? (isFullySigned({ contributors, signatures }) ? 'signed' : 'ready') : 'draft'

  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false
      return
    }
    setSaving(true)
    const timer = window.setTimeout(() => {
      saveSheet({ ...initial, song, contributors, agreed, signatures, status, updatedAt: new Date().toISOString() })
      setSaving(false)
    }, 500)
    return () => window.clearTimeout(timer)
  }, [initial, song, contributors, agreed, signatures, status])

  // Any change to the terms invalidates signatures collected on the previous version.
  const changeSong = (next: Song) => {
    setSong(next)
    setSignatures({})
  }
  const changeContributors = (update: (prev: Contributor[]) => Contributor[]) => {
    setContributors(update)
    setSignatures({})
  }
  const changeAgreed = (value: boolean) => {
    setAgreed(value)
    if (!value) setSignatures({})
  }

  const updateContributor = (id: string, patch: Partial<Contributor>) =>
    changeContributors((prev) => prev.map((c) => (c.id === id ? { ...c, ...patch } : c)))

  const splitEvenly = (key: ShareKey) =>
    changeContributors((prev) => {
      const shares = evenShares(prev.length)
      return prev.map((c, i) => ({ ...c, [key]: shares[i] }))
    })

  const toggleSignature = (id: string) =>
    setSignatures((prev) => {
      const next = { ...prev }
      if (next[id]) delete next[id]
      else next[id] = new Date().toISOString()
      return next
    })

  const goTo = (next: number) => {
    setStep(next)
    document.getElementById('builder')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  return (
    <section id="builder" className="scroll-mt-16">
      <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:py-12">
        <div className="mb-8 flex flex-col gap-4 print:hidden">
          <Link
            href="/dashboard/sheets"
            className="inline-flex w-fit items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <ChevronLeft className="size-4" aria-hidden="true" />
            Split sheets
          </Link>
          <div className="flex flex-wrap items-end justify-between gap-3">
            <h1 className="min-w-0 truncate text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
              {song.title.trim() || 'Untitled sheet'}
            </h1>
            <div className="flex items-center gap-2 text-xs">
              <span
                className={cn(
                  'rounded-full px-2.5 py-1 font-medium',
                  status === 'draft' ? 'bg-muted text-muted-foreground' : 'bg-accent text-accent-foreground',
                )}
              >
                {STATUS_LABEL[status]}
              </span>
              {signed > 0 && (
                <span className="rounded-full bg-chart-3/15 px-2.5 py-1 font-medium text-foreground">
                  {signed}/{contributors.length} signed · editing resets
                </span>
              )}
              <span className="flex items-center gap-1 text-muted-foreground" role="status" aria-live="polite">
                {saving ? (
                  <Loader2 className="size-3.5 animate-spin" aria-hidden="true" />
                ) : (
                  <Check className="size-3.5 text-primary" aria-hidden="true" />
                )}
                {saving ? 'Saving…' : 'Saved'}
              </span>
            </div>
          </div>
        </div>

        <nav aria-label="Builder steps" className="mb-8 lg:hidden">
          <ol className="grid grid-cols-3 gap-2">
            {STEPS.map((label, i) => (
              <li key={label}>
                <button
                  type="button"
                  onClick={() => goTo(i)}
                  aria-current={step === i ? 'step' : undefined}
                  className={cn(
                    'flex w-full flex-col gap-2 text-left text-xs font-medium transition-colors',
                    step === i ? 'text-foreground' : 'text-muted-foreground',
                  )}
                >
                  <span className={cn('h-1 rounded-full transition-colors', i <= step ? 'bg-primary' : 'bg-border')} />
                  {i + 1}. {label}
                </button>
              </li>
            ))}
          </ol>
        </nav>

        <div className="grid gap-10 lg:grid-cols-[1fr_400px] lg:gap-12">
          <div className="flex flex-col gap-12">
            <div className={cn(step !== 0 && 'hidden lg:block')}>
              <SongDetails song={song} onChange={changeSong} />
            </div>
            <div className={cn('flex flex-col gap-4', step !== 1 && 'hidden lg:flex')}>
              <AddressBookPicker
                existing={contributors}
                onPick={(c) =>
                  changeContributors((prev) => [...prev, { ...c, id: Math.random().toString(36).slice(2, 10), master: 0, publishing: 0 }])
                }
              />
              <ContributorsEditor
                contributors={contributors}
                masterTotal={masterTotal}
                publishingTotal={publishingTotal}
                onUpdate={updateContributor}
                onAdd={() => changeContributors((prev) => [...prev, newContributor()])}
                onRemove={(id) => changeContributors((prev) => prev.filter((c) => c.id !== id))}
                onSplitEvenly={splitEvenly}
              />
            </div>
            <div className={cn(step !== 2 && 'hidden lg:block')}>
              <AgreementStep
                agreed={agreed}
                onAgreedChange={changeAgreed}
                issues={issues}
                onDownload={() => window.print()}
                contributors={contributors}
                signatures={signatures}
                onToggleSignature={toggleSignature}
              />
            </div>
          </div>

          <aside aria-label="Live preview" className="hidden lg:block print:block">
            <div className="sticky top-24">
              <p className="mb-3 flex items-center gap-2 text-xs font-medium uppercase tracking-widest text-muted-foreground">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-60" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
                </span>
                Live preview
                <span className="ml-auto flex items-center gap-1 normal-case tracking-normal">
                  <Lock className="size-3" aria-hidden="true" />
                  Only you
                </span>
              </p>
              <SplitSheetPreview song={song} contributors={contributors} printable />
            </div>
          </aside>
        </div>
      </div>

      {/* Mobile: sticky step controls */}
      <div className="sticky bottom-0 z-30 border-t border-border bg-background/90 px-4 py-3 backdrop-blur-md lg:hidden print:hidden">
        <div className="mx-auto flex max-w-xl items-center gap-2">
          <Button
            variant="outline"
            size="icon-lg"
            onClick={() => goTo(Math.max(0, step - 1))}
            disabled={step === 0}
            aria-label="Previous step"
            className="h-11 w-11 rounded-full"
          >
            <ArrowLeft />
          </Button>
          <Button variant="outline" onClick={() => setPreviewOpen(true)} className="h-11 flex-1 rounded-full">
            <Eye data-icon="inline-start" />
            Preview
            <span className="ml-1 font-mono text-xs text-muted-foreground tabular-nums">
              {masterTotal}/{publishingTotal}
            </span>
          </Button>
          {step < STEPS.length - 1 ? (
            <Button onClick={() => goTo(step + 1)} className="h-11 flex-1 rounded-full">
              Next
              <ArrowRight data-icon="inline-end" />
            </Button>
          ) : (
            <Button onClick={() => window.print()} disabled={issues.length > 0 || !agreed} className="h-11 flex-1 rounded-full">
              Download
            </Button>
          )}
        </div>
      </div>

      {previewOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Split sheet preview"
          className="fixed inset-0 z-50 flex flex-col bg-foreground/40 backdrop-blur-sm animate-in fade-in lg:hidden"
          onClick={() => setPreviewOpen(false)}
          onKeyDown={(e) => e.key === 'Escape' && setPreviewOpen(false)}
        >
          <div
            className="mt-auto max-h-[88dvh] overflow-y-auto rounded-t-3xl bg-background p-4 pb-8 animate-in slide-in-from-bottom duration-300"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-3 flex items-center justify-between">
              <span className="text-sm font-medium">Live preview</span>
              <Button variant="ghost" size="icon" onClick={() => setPreviewOpen(false)} aria-label="Close preview" autoFocus>
                <X />
              </Button>
            </div>
            <SplitSheetPreview song={song} contributors={contributors} />
          </div>
        </div>
      )}
    </section>
  )
}
