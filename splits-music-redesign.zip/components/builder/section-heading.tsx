type Props = {
  id: string
  step: number
  title: string
  description?: string
  action?: React.ReactNode
}

export function SectionHeading({ id, step, title, description, action }: Props) {
  return (
    <div className="mb-6 flex items-start justify-between gap-4">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-foreground font-mono text-xs font-medium text-background">
          {step}
        </span>
        <div>
          <h2 id={id} className="text-xl font-semibold tracking-tight">
            {title}
          </h2>
          {description && <p className="mt-1 text-pretty text-sm leading-relaxed text-muted-foreground">{description}</p>}
        </div>
      </div>
      {action}
    </div>
  )
}
