import { Logo } from './site-header'

export function SiteFooter() {
  return (
    <footer className="border-t border-border print:hidden">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-10 sm:px-6 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-col gap-2">
          <Logo />
          <p className="max-w-md text-xs leading-relaxed text-muted-foreground">
            Self-help templates for music ownership. Not a law firm and not legal advice.
          </p>
        </div>
        <p className="text-xs text-muted-foreground">{`© ${new Date().getFullYear()} Splits Music · Made in Lagos`}</p>
      </div>
    </footer>
  )
}
