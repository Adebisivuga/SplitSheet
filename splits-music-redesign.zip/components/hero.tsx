import Link from 'next/link'
import { ArrowRight, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { HeroLiveSheet } from './hero-live-sheet'

export function Hero() {
  return (
    <section id="top" className="mx-auto grid max-w-6xl items-center gap-12 px-4 pb-16 pt-12 sm:px-6 md:pt-20 lg:grid-cols-[1.1fr_0.9fr] lg:pb-24">
      <div>
        <p className="mb-5 inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
          <span className="h-1.5 w-1.5 rounded-full bg-primary" aria-hidden="true" />
          Built for Nigerian artists, producers and writers
        </p>
        <h1 className="text-balance text-4xl font-semibold leading-[1.05] tracking-tight sm:text-5xl lg:text-6xl">
          Agree who owns the song <span className="text-primary">before it blows.</span>
        </h1>
        <p className="mt-6 max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
          {"Build a split sheet with your producer, co-writers and label in minutes. Get everyone's share in writing, then register it properly in Nigeria."}
        </p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <Button nativeButton={false} render={<Link href="/dashboard/sheets/new" />} size="lg" className="h-12 rounded-full px-6 text-base">
            Build your split sheet
            <ArrowRight data-icon="inline-end" />
          </Button>
          <Button nativeButton={false} render={<Link href="/dashboard" />} size="lg" variant="outline" className="h-12 rounded-full px-6 text-base">
            My sheets
          </Button>
        </div>
        <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted-foreground">
          {['Free to use', 'IPI + PRO details', 'Printable PDF'].map((item) => (
            <li key={item} className="flex items-center gap-1.5">
              <Check className="size-4 text-primary" aria-hidden="true" />
              {item}
            </li>
          ))}
        </ul>
      </div>

      <HeroLiveSheet />
    </section>
  )
}
