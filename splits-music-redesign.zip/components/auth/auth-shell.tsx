import { Check, Lock } from 'lucide-react'
import { Logo } from '@/components/site-header'

const POINTS = [
  'Only you and your co-writers can open your sheets',
  'IPI, PRO and publisher details saved for every split',
  'Drafts, signatures and finished sheets in one dashboard',
]

export function AuthShell({ children }: { children: React.ReactNode }) {
  return (
    <main className="flex min-h-[calc(100dvh-3rem)] flex-col lg:flex-row">
      <section className="flex flex-1 flex-col px-6 py-8 sm:px-10">
        <Logo />
        <div className="flex flex-1 items-center justify-center py-10">{children}</div>
      </section>

      <aside className="hidden flex-1 flex-col justify-between bg-foreground p-12 text-background lg:flex">
        <span className="flex w-fit items-center gap-2 rounded-full bg-background/10 px-3 py-1.5 text-sm">
          <Lock className="h-3.5 w-3.5" aria-hidden="true" />
          Private by default
        </span>
        <div>
          <p className="max-w-md text-balance text-4xl font-semibold leading-tight tracking-tight">
            Your splits, agreed on before the song drops.
          </p>
          <ul className="mt-8 flex flex-col gap-4">
            {POINTS.map((point) => (
              <li key={point} className="flex items-start gap-3 text-background/80">
                <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-accent text-accent-foreground">
                  <Check className="h-3 w-3" aria-hidden="true" />
                </span>
                {point}
              </li>
            ))}
          </ul>
        </div>
        <p className="text-sm text-background/50">Splits Music</p>
      </aside>
    </main>
  )
}
