'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Eye, EyeOff, Info, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

type Mode = 'login' | 'signup'

const COPY = {
  login: {
    title: 'Welcome back',
    subtitle: 'Log in to see your private split sheets.',
    submit: 'Log in',
    switchText: 'New to Splits Music?',
    switchLabel: 'Create an account',
    switchHref: '/signup',
  },
  signup: {
    title: 'Create your account',
    subtitle: 'Keep every split sheet private and in one place.',
    submit: 'Create account',
    switchText: 'Already have an account?',
    switchLabel: 'Log in',
    switchHref: '/login',
  },
} as const

export function AuthForm({ mode }: { mode: Mode }) {
  const router = useRouter()
  const copy = COPY[mode]
  const [showPassword, setShowPassword] = useState(false)
  const [pending, setPending] = useState(false)
  const [error, setError] = useState<string | null>(null)

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const data = new FormData(event.currentTarget)
    const email = String(data.get('email') ?? '').trim()
    const password = String(data.get('password') ?? '')
    const name = String(data.get('name') ?? '').trim()

    if (mode === 'signup' && !name) return setError('Please enter your name.')
    if (!/^\S+@\S+\.\S+$/.test(email)) return setError('Please enter a valid email address.')
    if (password.length < 8) return setError('Password must be at least 8 characters.')

    setError(null)
    setPending(true)
    setTimeout(() => router.push('/dashboard'), 600)
  }

  return (
    <div className="w-full max-w-sm">
      <h1 className="text-balance text-3xl font-semibold tracking-tight">{copy.title}</h1>
      <p className="mt-2 text-pretty text-muted-foreground">{copy.subtitle}</p>

      <div
        role="note"
        className="mt-6 flex gap-2.5 rounded-xl border border-border bg-secondary p-3 text-sm text-muted-foreground"
      >
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-foreground" aria-hidden="true" />
        <p>
          <span className="font-medium text-foreground">Preview mode.</span> Accounts aren&apos;t live yet. This form
          takes you to the dashboard without creating an account.
        </p>
      </div>

      <form onSubmit={handleSubmit} noValidate className="mt-6 flex flex-col gap-4">
        {mode === 'signup' && (
          <div className="flex flex-col gap-2">
            <Label htmlFor="name">Full name</Label>
            <Input id="name" name="name" autoComplete="name" placeholder="Ada Okafor" className="h-11" />
          </div>
        )}

        <div className="flex flex-col gap-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            placeholder="you@example.com"
            className="h-11"
          />
        </div>

        <div className="flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="password">Password</Label>
            {mode === 'login' && (
              <span className="text-xs text-muted-foreground">Password reset coming soon</span>
            )}
          </div>
          <div className="relative">
            <Input
              id="password"
              name="password"
              type={showPassword ? 'text' : 'password'}
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
              placeholder={mode === 'signup' ? 'At least 8 characters' : 'Your password'}
              className="h-11 pr-11"
            />
            <button
              type="button"
              onClick={() => setShowPassword((v) => !v)}
              aria-label={showPassword ? 'Hide password' : 'Show password'}
              className="absolute inset-y-0 right-0 flex w-11 items-center justify-center rounded-r-lg text-muted-foreground transition-colors hover:text-foreground"
            >
              {showPassword ? <EyeOff className="h-4 w-4" aria-hidden="true" /> : <Eye className="h-4 w-4" aria-hidden="true" />}
            </button>
          </div>
        </div>

        {error && (
          <p role="alert" className="text-sm font-medium text-destructive">
            {error}
          </p>
        )}

        <Button type="submit" disabled={pending} className="mt-1 h-11 rounded-xl text-base">
          {pending && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
          {copy.submit}
        </Button>
      </form>

      <p className="mt-6 text-center text-sm text-muted-foreground">
        {copy.switchText}{' '}
        <Link href={copy.switchHref} className="font-medium text-foreground underline-offset-4 hover:underline">
          {copy.switchLabel}
        </Link>
      </p>
    </div>
  )
}
