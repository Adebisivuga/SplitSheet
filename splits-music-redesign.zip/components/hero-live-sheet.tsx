'use client'

import { useEffect, useState } from 'react'
import { Shuffle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { swatchFor } from '@/lib/splits'

type SampleSheet = {
  title: string
  artist: string
  pro: string
  people: { name: string; role: string; master: number; publishing: number }[]
}

const SAMPLES: SampleSheet[] = [
  {
    title: 'Lagos Nights',
    artist: 'Tems O. feat. Ayo B.',
    pro: 'COSON',
    people: [
      { name: 'Tems O.', role: 'Main artist', master: 50, publishing: 40 },
      { name: 'Kel P.', role: 'Producer', master: 30, publishing: 25 },
      { name: 'Ayo B.', role: 'Featured artist', master: 20, publishing: 35 },
    ],
  },
  {
    title: 'Owambe Season',
    artist: 'Kaffy D.',
    pro: 'MCSN',
    people: [
      { name: 'Kaffy D.', role: 'Main artist', master: 60, publishing: 45 },
      { name: 'Sarz K.', role: 'Producer', master: 40, publishing: 20 },
      { name: 'Ife N.', role: 'Co-writer', master: 0, publishing: 35 },
    ],
  },
  {
    title: 'Danfo Driver',
    artist: 'Rema J. x Lojay',
    pro: 'PRS for Music',
    people: [
      { name: 'Rema J.', role: 'Main artist', master: 45, publishing: 40 },
      { name: 'Lojay', role: 'Featured artist', master: 25, publishing: 30 },
      { name: 'London B.', role: 'Producer', master: 30, publishing: 30 },
    ],
  },
  {
    title: 'Harmattan Love',
    artist: 'Simi A.',
    pro: 'COSON',
    people: [
      { name: 'Simi A.', role: 'Main artist', master: 70, publishing: 50 },
      { name: 'Oscar H.', role: 'Producer', master: 30, publishing: 20 },
      { name: 'Tolu F.', role: 'Songwriter', master: 0, publishing: 30 },
    ],
  },
  {
    title: 'Third Mainland',
    artist: 'Asake T. feat. Fave',
    pro: 'ASCAP',
    people: [
      { name: 'Asake T.', role: 'Main artist', master: 55, publishing: 45 },
      { name: 'Magicsticks', role: 'Producer', master: 35, publishing: 30 },
      { name: 'Fave', role: 'Featured artist', master: 10, publishing: 25 },
    ],
  },
]

type View = 'master' | 'publishing'

export function HeroLiveSheet() {
  const [index, setIndex] = useState(0)
  const [view, setView] = useState<View>('master')
  const [paused, setPaused] = useState(false)

  const shuffle = () =>
    setIndex((current) => {
      let next = current
      while (next === current) next = Math.floor(Math.random() * SAMPLES.length)
      return next
    })

  useEffect(() => {
    shuffle()
  }, [])

  useEffect(() => {
    if (paused) return
    const timer = window.setInterval(shuffle, 5000)
    return () => window.clearInterval(timer)
  }, [paused])

  const sheet = SAMPLES[index]

  return (
    <div className="relative" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
      <div aria-hidden="true" className="absolute -inset-4 -z-10 rounded-[2rem] bg-accent/60 blur-2xl" />
      <figure className="rounded-3xl border border-border bg-card p-6 shadow-xl shadow-foreground/5 sm:p-8">
        <figcaption className="flex items-center justify-between gap-3">
          <span className="flex items-center gap-2 text-xs font-medium uppercase tracking-widest text-muted-foreground">
            <span className="relative flex h-2 w-2" aria-hidden="true">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
            </span>
            Sample sheet
          </span>
          <div role="tablist" aria-label="Share type" className="flex rounded-full bg-muted p-0.5 text-xs font-medium">
            {(['master', 'publishing'] as const).map((key) => (
              <button
                key={key}
                type="button"
                role="tab"
                aria-selected={view === key}
                onClick={() => setView(key)}
                className={
                  view === key
                    ? 'rounded-full bg-background px-3 py-1 capitalize text-foreground shadow-sm'
                    : 'rounded-full px-3 py-1 capitalize text-muted-foreground hover:text-foreground'
                }
              >
                {key}
              </button>
            ))}
          </div>
        </figcaption>

        <div aria-live="polite">
          <p key={sheet.title} className="mt-5 text-2xl font-semibold tracking-tight animate-in fade-in slide-in-from-bottom-1 duration-500">
            {sheet.title}
          </p>
          <p className="text-sm text-muted-foreground">
            {sheet.artist} · <span className="font-mono text-xs">{sheet.pro}</span>
          </p>
        </div>

        <div
          className="mt-6 flex h-3 gap-1 overflow-hidden rounded-full"
          role="img"
          aria-label={`${view} split: ${sheet.people.map((p) => `${p.name} ${p[view]}%`).join(', ')}`}
        >
          {sheet.people.map((p, i) => (
            <span
              key={i}
              className={`${swatchFor(i)} rounded-full transition-all duration-700 ease-out`}
              style={{ width: `${p[view]}%` }}
            />
          ))}
        </div>

        <ul className="mt-6 divide-y divide-border">
          {sheet.people.map((p, i) => (
            <li key={i} className="flex items-center gap-3 py-3">
              <span className={`h-2.5 w-2.5 shrink-0 rounded-full ${swatchFor(i)}`} aria-hidden="true" />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{p.name}</p>
                <p className="text-xs text-muted-foreground">{p.role}</p>
              </div>
              <span className="font-mono text-sm font-medium tabular-nums">{p[view]}%</span>
            </li>
          ))}
        </ul>

        <div className="mt-4 flex items-center justify-between gap-3 border-t border-border pt-4">
          <p className="text-xs text-muted-foreground">Your own sheets stay private in your dashboard.</p>
          <Button variant="ghost" size="sm" onClick={shuffle} className="shrink-0 rounded-full">
            <Shuffle data-icon="inline-start" />
            Shuffle
          </Button>
        </div>
      </figure>
    </div>
  )
}
