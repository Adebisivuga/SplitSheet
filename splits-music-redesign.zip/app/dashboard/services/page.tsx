import type { Metadata } from 'next'
import { ArrowUpRight, BookOpen, Scale } from 'lucide-react'
import { PageContainer, PageHeader } from '@/components/app/page-header'
import { PartnerServices } from '@/components/partner-services'
import { SPONSORED_ADS } from '@/lib/sponsored-ads'
import { cn } from '@/lib/utils'

export const metadata: Metadata = { title: 'Services' }

const AD_ICONS = { publishing: BookOpen, legal: Scale } as const

export default function ServicesPage() {
  return (
    <PageContainer>
      <PageHeader
        eyebrow="Services"
        title="Get your music registered"
        description="Trusted third-party partners for ISRC codes, credits, metadata, publishing administration and legal help. Links open on the partner's site."
      />

      <div className="mt-8 grid gap-4 lg:grid-cols-2">
        {SPONSORED_ADS.map((ad) => {
          const Icon = AD_ICONS[ad.id]
          const isPrimary = ad.id === 'publishing'
          return (
            <a
              key={ad.id}
              href={ad.href}
              target="_blank"
              rel="noopener noreferrer sponsored"
              className={cn(
                'group flex flex-col gap-4 rounded-3xl p-6 sm:p-8',
                isPrimary ? 'bg-primary text-primary-foreground' : 'bg-foreground text-background',
              )}
            >
              <span className="flex items-center gap-3">
                <span
                  className={cn(
                    'flex size-12 shrink-0 items-center justify-center rounded-2xl',
                    isPrimary ? 'bg-primary-foreground/15' : 'bg-background/15',
                  )}
                >
                  <Icon className="size-6" aria-hidden="true" />
                </span>
                <span className="text-xs font-medium uppercase tracking-wider opacity-80">
                  Sponsored · {ad.category}
                </span>
              </span>
              <span className="flex-1">
                <span className="block text-xl font-semibold">{ad.headline}</span>
                <span className="mt-1 block text-sm opacity-90">{ad.description}</span>
              </span>
              <span
                className={cn(
                  'inline-flex w-fit items-center gap-1 rounded-full px-4 py-2 text-sm font-medium',
                  isPrimary ? 'bg-primary-foreground text-primary' : 'bg-background text-foreground',
                )}
              >
                {ad.cta}
                <ArrowUpRight
                  className="size-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
                  aria-hidden="true"
                />
                <span className="sr-only">(opens in a new tab)</span>
              </span>
            </a>
          )
        })}
      </div>

      <PartnerServices variant="compact" className="mt-10" />
    </PageContainer>
  )
}
