import type { Metadata } from 'next'
import { Catalog } from '@/components/dashboard/catalog'

export const metadata: Metadata = { title: 'Catalog' }

export default function CatalogPage() {
  return <Catalog />
}
