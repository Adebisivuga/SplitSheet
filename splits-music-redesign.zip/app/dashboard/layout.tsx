import type { Metadata } from 'next'
import { AppShell } from '@/components/app/app-shell'

export const metadata: Metadata = {
  title: {
    default: 'Workspace · Splits Music',
    template: '%s · Splits Music',
  },
  description: 'Your private split sheets, catalog, collaborators and royalty tools.',
  robots: { index: false },
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return <AppShell>{children}</AppShell>
}
