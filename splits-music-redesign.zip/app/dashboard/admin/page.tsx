import type { Metadata } from 'next'
import { AdminRequests } from '@/components/dashboard/admin-requests'

export const metadata: Metadata = {
  title: 'Admin · Removal requests — Splits Music',
}

export default function AdminPage() {
  return <AdminRequests />
}
