import type { Metadata } from 'next'
import { Royalties } from '@/components/dashboard/royalties'

export const metadata: Metadata = { title: 'Royalty calculator' }

export default function RoyaltiesPage() {
  return <Royalties />
}
