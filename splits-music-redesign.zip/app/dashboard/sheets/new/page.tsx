import { NewSheetRedirect } from '@/components/dashboard/new-sheet-redirect'

export default function NewSheetPage() {
  return <NewSheetRedirect />
}
