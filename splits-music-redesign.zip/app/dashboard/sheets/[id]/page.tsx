import { SheetEditor } from '@/components/dashboard/sheet-editor'

export default async function SheetPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  return <SheetEditor id={id} />
}
