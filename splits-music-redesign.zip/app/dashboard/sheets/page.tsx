import type { Metadata } from 'next'
import { SheetsDashboard } from '@/components/dashboard/sheets-dashboard'

export const metadata: Metadata = { title: 'Split sheets' }

export default function SheetsPage() {
  return <SheetsDashboard />
}
