import { AfterSigning } from '@/components/after-signing'
import { Hero } from '@/components/hero'
import { HowItWorks } from '@/components/how-it-works'
import { PartnerServices } from '@/components/partner-services'
import { SiteFooter } from '@/components/site-footer'
import { SiteHeader } from '@/components/site-header'

export default function Page() {
  return (
    <>
      <SiteHeader />
      <main>
        <Hero />
        <HowItWorks />
        <PartnerServices />
        <AfterSigning />
      </main>
      <SiteFooter />
    </>
  )
}
