export type SponsoredAd = {
  id: 'publishing' | 'legal'
  category: string
  headline: string
  tagline: string
  description: string
  href: string
  cta: string
}

export const SPONSORED_ADS: SponsoredAd[] = [
  {
    id: 'publishing',
    category: 'Publishing',
    headline: 'Do you need a publisher?',
    tagline: 'Vuga can collect your publishing royalties for you.',
    description:
      'Vuga helps independent writers register works and collect publishing royalties worldwide.',
    href: 'https://www.vuga.org',
    cta: 'Visit Vuga',
  },
  {
    id: 'legal',
    category: 'Legal',
    headline: 'Get Legal Service',
    tagline: 'Have a music lawyer review your split sheet and contracts.',
    description:
      'Talk to an entertainment lawyer about split disputes, publishing deals, sync licences and label contracts before you sign.',
    href: 'https://www.vuga.org',
    cta: 'Get legal help',
  },
]
