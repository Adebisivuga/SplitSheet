export type Contributor = {
  id: string
  name: string
  role: string
  email: string
  master: number
  publishing: number
  ipi: string
  pro: string
  publisherName: string
  publisherIpi: string
  publisherPro: string
}

export const PROS = [
  'COSON',
  'MCSN',
  'ASCAP',
  'BMI',
  'SESAC',
  'GMR',
  'PRS for Music',
  'SOCAN',
  'SAMRO',
  'GHAMRO',
  'MCSK',
  'GEMA',
  'SACEM',
  'APRA AMCOS',
  'JASRAC',
] as const

export function normalizeIpi(value: string) {
  return value.replace(/\D/g, '').slice(0, 11)
}

export function isValidIpi(value: string) {
  return /^\d{9,11}$/.test(value)
}

export type Song = {
  title: string
  artist: string
  isrc: string
  date: string
  masterOwner: string
  masterOwnerType: string
}

export const MASTER_OWNER_TYPES = [
  'Independent artist',
  'Record label',
  'Production company',
  'Distributor',
  'Joint ownership',
] as const

export function withSongDefaults(song: Partial<Song> | undefined): Song {
  return {
    title: '',
    artist: '',
    isrc: '',
    date: '',
    masterOwner: '',
    masterOwnerType: '',
    ...song,
  }
}

export type ShareKey = 'master' | 'publishing'

export const ROLES = [
  'Main artist',
  'Featured artist',
  'Producer',
  'Co-writer',
  'Songwriter',
  'Engineer',
  'Label',
  'Publisher',
] as const

export const SWATCHES = [
  'bg-chart-1',
  'bg-chart-2',
  'bg-chart-3',
  'bg-chart-4',
  'bg-chart-5',
] as const

export function swatchFor(index: number) {
  return SWATCHES[index % SWATCHES.length]
}

export function total(contributors: Contributor[], key: ShareKey) {
  return Math.round(contributors.reduce((sum, c) => sum + (Number(c[key]) || 0), 0) * 100) / 100
}

export function evenShares(count: number) {
  if (count === 0) return []
  const base = Math.floor((100 / count) * 100) / 100
  const shares = Array.from({ length: count }, () => base)
  shares[0] = Math.round((100 - base * (count - 1)) * 100) / 100
  return shares
}

export function sheetIssues(song: Song, contributors: Contributor[]) {
  const masterTotal = total(contributors, 'master')
  const publishingTotal = total(contributors, 'publishing')
  const list: string[] = []
  if (!song.title.trim()) list.push('Add a song title')
  if (!song.artist.trim()) list.push('Add the main artist')
  if (!song.masterOwner.trim()) list.push('Add who owns the master')
  if (contributors.some((c) => !c.name.trim())) list.push('Name every contributor')
  if (contributors.some((c) => !isValidIpi(c.ipi))) list.push('Add a 9–11 digit IPI for every contributor')
  if (contributors.some((c) => !c.pro.trim())) list.push('Add the PRO / society for every contributor')
  if (contributors.some((c) => !c.publisherName.trim())) list.push('Add a publisher name for every contributor')
  if (contributors.some((c) => !isValidIpi(c.publisherIpi))) list.push('Add a 9–11 digit publisher IPI for every contributor')
  if (contributors.some((c) => !c.publisherPro.trim())) list.push('Add the publisher’s society for every contributor')
  if (masterTotal !== 100) list.push(`Master adds up to ${masterTotal}%, not 100%`)
  if (publishingTotal !== 100) list.push(`Publishing adds up to ${publishingTotal}%, not 100%`)
  return list
}

export function initials(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean)
  if (parts.length === 0) return '?'
  return (parts[0][0] + (parts[1]?.[0] ?? '')).toUpperCase()
}

export function newContributor(role: string = 'Co-writer'): Contributor {
  return {
    id: Math.random().toString(36).slice(2, 10),
    name: '',
    role,
    email: '',
    master: 0,
    publishing: 0,
    ipi: '',
    pro: '',
    publisherName: '',
    publisherIpi: '',
    publisherPro: '',
  }
}
