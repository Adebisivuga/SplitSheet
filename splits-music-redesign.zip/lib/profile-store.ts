'use client'

import { createLocalStore } from './local-store'
import { isValidIpi } from './splits'

export type Profile = {
  name: string
  email: string
  artistName: string
  role: string
  ipi: string
  pro: string
  publisherName: string
  publisherIpi: string
  publisherPro: string
  prefill: boolean
}

export const EMPTY_PROFILE: Profile = {
  name: '',
  email: '',
  artistName: '',
  role: 'Main artist',
  ipi: '',
  pro: '',
  publisherName: '',
  publisherIpi: '',
  publisherPro: '',
  prefill: true,
}

const store = createLocalStore<Profile>('splits-music:profile:v1', EMPTY_PROFILE)

export const readProfile = store.read
export const useProfile = store.useValue
export const clearProfile = store.clear

export function saveProfile(patch: Partial<Profile>) {
  store.write({ ...store.read(), ...patch })
}

export function profileChecks(profile: Profile) {
  return [
    { label: 'Your name', done: !!profile.name.trim() },
    { label: 'Writer IPI', done: isValidIpi(profile.ipi) },
    { label: 'PRO / society', done: !!profile.pro.trim() },
    { label: 'Publisher name', done: !!profile.publisherName.trim() },
    { label: 'Publisher IPI', done: isValidIpi(profile.publisherIpi) },
    { label: 'Publisher society', done: !!profile.publisherPro.trim() },
  ]
}

export function profileCompleteness(profile: Profile) {
  const checks = profileChecks(profile)
  return Math.round((checks.filter((c) => c.done).length / checks.length) * 100)
}
