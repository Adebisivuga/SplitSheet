'use client'

import { useSyncExternalStore } from 'react'

export function createLocalStore<T>(key: string, fallback: T) {
  const listeners = new Set<() => void>()
  let cachedRaw: string | null | undefined
  let cached: T = fallback

  function parse(raw: string | null): T {
    if (!raw) return fallback
    try {
      const value = JSON.parse(raw)
      if (Array.isArray(fallback)) return (Array.isArray(value) ? value : fallback) as T
      if (fallback && typeof fallback === 'object') {
        return value && typeof value === 'object' ? { ...fallback, ...value } : fallback
      }
      return value as T
    } catch {
      return fallback
    }
  }

  function read(): T {
    if (typeof window === 'undefined') return fallback
    const raw = window.localStorage.getItem(key)
    if (raw !== cachedRaw) {
      cachedRaw = raw
      cached = parse(raw)
    }
    return cached
  }

  function write(value: T) {
    window.localStorage.setItem(key, JSON.stringify(value))
    listeners.forEach((listener) => listener())
  }

  function clear() {
    window.localStorage.removeItem(key)
    listeners.forEach((listener) => listener())
  }

  function subscribe(listener: () => void) {
    listeners.add(listener)
    const onStorage = (event: StorageEvent) => event.key === key && listener()
    window.addEventListener('storage', onStorage)
    return () => {
      listeners.delete(listener)
      window.removeEventListener('storage', onStorage)
    }
  }

  function useValue() {
    return useSyncExternalStore(subscribe, read, () => fallback)
  }

  return { read, write, clear, useValue }
}
