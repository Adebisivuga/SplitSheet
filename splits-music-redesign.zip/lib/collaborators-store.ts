'use client'

import { createLocalStore } from './local-store'
import type { Contributor } from './splits'

export type Collaborator = Omit<Contributor, 'master' | 'publishing'>

const EMPTY: Collaborator[] = []
const store = createLocalStore<Collaborator[]>('splits-music:collaborators:v1', EMPTY)

export const useCollaborators = store.useValue
export const clearCollaborators = store.clear

export function collaboratorKey(name: string) {
  return name.trim().toLowerCase()
}

export function saveCollaborator(collaborator: Collaborator) {
  const list = store.read()
  const exists = list.some((c) => c.id === collaborator.id)
  store.write(exists ? list.map((c) => (c.id === collaborator.id ? collaborator : c)) : [collaborator, ...list])
}

export function deleteCollaborator(id: string) {
  store.write(store.read().filter((c) => c.id !== id))
}

export function toCollaborator(c: Contributor): Collaborator {
  const { master: _m, publishing: _p, ...rest } = c
  return rest
}
