'use client'

import { useSyncExternalStore } from 'react'
import { newContributor, withSongDefaults, type Contributor, type Song } from './splits'
import { readProfile } from './profile-store'

export type SheetStatus = 'draft' | 'ready' | 'signed'

export type RemovalRequest = {
  reason: string
  requestedAt: string
  status: 'pending' | 'approved' | 'rejected'
  resolvedAt?: string
}

export type SavedSheet = {
  id: string
  song: Song
  contributors: Contributor[]
  agreed: boolean
  status: SheetStatus
  signatures?: Record<string, string>
  removal?: RemovalRequest
  archived?: boolean
  createdAt: string
  updatedAt: string
}

export function signedCount(sheet: Pick<SavedSheet, 'contributors' | 'signatures'>) {
  return sheet.contributors.filter((c) => sheet.signatures?.[c.id]).length
}

export function isFullySigned(sheet: Pick<SavedSheet, 'contributors' | 'signatures'>) {
  return sheet.contributors.length > 0 && signedCount(sheet) === sheet.contributors.length
}

export const STATUS_LABEL: Record<SheetStatus, string> = {
  draft: 'Draft',
  ready: 'Ready to sign',
  signed: 'Fully signed',
}

const STORAGE_KEY = 'splits-music:sheets:v1'
const EMPTY: SavedSheet[] = []
const listeners = new Set<() => void>()

let cachedRaw: string | null | undefined
let cachedSheets: SavedSheet[] = EMPTY
let cachedVisible: SavedSheet[] = EMPTY

function readSheets(): SavedSheet[] {
  const raw = window.localStorage.getItem(STORAGE_KEY)
  if (raw !== cachedRaw) {
    cachedRaw = raw
    try {
      const parsed = raw ? JSON.parse(raw) : []
      cachedSheets = Array.isArray(parsed)
        ? parsed.map((s: SavedSheet) => ({ ...s, song: withSongDefaults(s.song) }))
        : EMPTY
    } catch {
      cachedSheets = EMPTY
    }
    cachedVisible = cachedSheets.filter((s) => !s.archived)
  }
  return cachedSheets
}

function readVisibleSheets(): SavedSheet[] {
  readSheets()
  return cachedVisible
}

function updateSheet(id: string, patch: (sheet: SavedSheet) => SavedSheet) {
  writeSheets(readSheets().map((s) => (s.id === id ? patch(s) : s)))
}

function writeSheets(sheets: SavedSheet[]) {
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(sheets))
  listeners.forEach((listener) => listener())
}

function subscribe(listener: () => void) {
  listeners.add(listener)
  const onStorage = (event: StorageEvent) => event.key === STORAGE_KEY && listener()
  window.addEventListener('storage', onStorage)
  return () => {
    listeners.delete(listener)
    window.removeEventListener('storage', onStorage)
  }
}

/** Sheets the user can see. Archived sheets (removal approved by an admin) are excluded. */
export function useSheets() {
  return useSyncExternalStore(subscribe, readVisibleSheets, () => EMPTY)
}

/** Every sheet including archived ones — for the admin review queue only. */
export function useAllSheets() {
  return useSyncExternalStore(subscribe, readSheets, () => EMPTY)
}

const noopSubscribe = () => () => {}

export function useHydrated() {
  return useSyncExternalStore(
    noopSubscribe,
    () => true,
    () => false,
  )
}

function makeId() {
  return typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID().slice(0, 8)
    : Math.random().toString(36).slice(2, 10)
}

export function createSheet(): SavedSheet {
  const now = new Date().toISOString()
  const profile = readProfile()
  const usePrefill = profile.prefill && !!profile.name.trim()
  const me = usePrefill
    ? {
        name: profile.name,
        email: profile.email,
        role: profile.role || 'Main artist',
        ipi: profile.ipi,
        pro: profile.pro,
        publisherName: profile.publisherName,
        publisherIpi: profile.publisherIpi,
        publisherPro: profile.publisherPro,
      }
    : {}
  const sheet: SavedSheet = {
    id: makeId(),
    song: withSongDefaults({ artist: usePrefill ? profile.artistName : '', date: now.slice(0, 10) }),
    contributors: [
      { ...newContributor('Main artist'), ...me, master: 50, publishing: 50 },
      { ...newContributor('Producer'), master: 50, publishing: 0 },
      { ...newContributor('Co-writer'), master: 0, publishing: 50 },
    ],
    agreed: false,
    status: 'draft',
    createdAt: now,
    updatedAt: now,
  }
  writeSheets([sheet, ...readSheets()])
  return sheet
}

export function saveSheet(sheet: SavedSheet) {
  const sheets = readSheets()
  const exists = sheets.some((s) => s.id === sheet.id)
  writeSheets(exists ? sheets.map((s) => (s.id === sheet.id ? sheet : s)) : [sheet, ...sheets])
}

export function clearSheets() {
  writeSheets([])
}

export function canDelete(sheet: SavedSheet) {
  return !isFullySigned(sheet)
}

/** Drafts and unsigned sheets can be deleted. Fully signed sheets need an approved removal request. */
export function deleteSheet(id: string) {
  const sheet = readSheets().find((s) => s.id === id)
  if (!sheet || !canDelete(sheet)) return false
  writeSheets(readSheets().filter((s) => s.id !== id))
  return true
}

export function requestRemoval(id: string, reason: string) {
  const now = new Date().toISOString()
  updateSheet(id, (s) => ({ ...s, removal: { reason: reason.trim(), requestedAt: now, status: 'pending' } }))
}

export function cancelRemoval(id: string) {
  updateSheet(id, (s) => ({ ...s, removal: undefined }))
}

export function resolveRemoval(id: string, approve: boolean) {
  const now = new Date().toISOString()
  updateSheet(id, (s) =>
    s.removal
      ? { ...s, archived: approve, removal: { ...s.removal, status: approve ? 'approved' : 'rejected', resolvedAt: now } }
      : s,
  )
}

export function restoreSheet(id: string) {
  updateSheet(id, (s) => ({ ...s, archived: false, removal: undefined }))
}

export function duplicateSheet(id: string) {
  const source = readSheets().find((s) => s.id === id)
  if (!source) return
  const now = new Date().toISOString()
  const copy: SavedSheet = {
    ...structuredClone(source),
    id: makeId(),
    song: { ...source.song, title: source.song.title ? `${source.song.title} (copy)` : '' },
    agreed: false,
    status: 'draft',
    signatures: {},
    removal: undefined,
    archived: false,
    createdAt: now,
    updatedAt: now,
  }
  writeSheets([copy, ...readSheets()])
  return copy.id
}
