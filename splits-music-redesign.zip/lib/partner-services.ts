export type PartnerService = {
  name: string
  description: string
  href: string
  cta: string
}

export const ISRC_SERVICES: PartnerService[] = [
  {
    name: 'US ISRC Agency',
    description: 'Register as an ISRC manager and buy codes for your recordings.',
    href: 'https://www.usisrc.org',
    cta: 'Buy ISRC codes',
  },
  {
    name: 'International ISRC Agency',
    description: 'Outside the US? Find the official national agency for your country.',
    href: 'https://isrc.ifpi.org',
    cta: 'Find your agency',
  },
]

export const METADATA_SERVICES: PartnerService[] = [
  {
    name: 'Muso.AI',
    description: 'Claim and verify your credits so every contributor is listed.',
    href: 'https://muso.ai',
    cta: 'Verify credits',
  },
  {
    name: 'Jaxsta',
    description: 'Official, label-sourced music credits and metadata.',
    href: 'https://jaxsta.com',
    cta: 'Manage metadata',
  },
  {
    name: 'SoundExchange ISRC Search',
    description: 'Look up an existing ISRC and check the recording metadata.',
    href: 'https://isrc.soundexchange.com',
    cta: 'Search ISRCs',
  },
]

export const ISRC_PURCHASE_URL = ISRC_SERVICES[0].href
